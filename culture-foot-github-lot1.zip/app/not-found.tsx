import Link from 'next/link'

export default function NotFound() {
  return (
    <main className="site-shell">
      <section className="home-hero">
        <div className="eyebrow">Culture Foot</div>
        <h1>Cette Page N’Est Pas Encore Dans Le Musée.</h1>
        <p className="hero-copy">Mais le voyage continue ailleurs.</p>
        <Link className="primary-button" href="/">Retour À L’Accueil</Link>
      </section>
    </main>
  )
}

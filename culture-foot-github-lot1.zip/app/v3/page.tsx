import { CultureFootV3Hub } from '@/components/v3/CultureFootV3Hub'

export default function V3Page() {
  return <CultureFootV3Hub />
}

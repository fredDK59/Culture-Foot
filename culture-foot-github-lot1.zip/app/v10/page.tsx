import Link from 'next/link'

export default function V10Page() {
  return <main className="site-shell"><header className="site-header"><Link className="brand" href="/">CULTURE FOOT</Link><span className="eyebrow">V10</span></header><section className="home-hero" style={{ minHeight: 'auto', padding: '100px 0' }}><div className="eyebrow">Culture Foot Public</div><h1>Entrez Pour Une Réponse.<br/><em>Restez Pour Le Voyage.</em></h1><p className="hero-copy">La destination finale du programme V5→V10 est un produit footballistique vivant, sourcé, interconnecté et évolutif.</p><div className="home-actions"><Link className="primary-button" href="/">Entrer Dans Culture Foot</Link><Link className="secondary-button" href="/parcours">Mon Parcours</Link></div></section></main>
}

'use client'

export default function Error({ reset }: { error: Error & { digest?: string }, reset: () => void }) {
  return (
    <main className="site-shell">
      <section className="home-hero">
        <div className="eyebrow">Culture Foot</div>
        <h1>Une Petite Passe Manquée.</h1>
        <p className="hero-copy">Le terrain est toujours là. On peut reprendre l’action.</p>
        <button className="primary-button" onClick={() => reset()}>Reprendre</button>
      </section>
    </main>
  )
}

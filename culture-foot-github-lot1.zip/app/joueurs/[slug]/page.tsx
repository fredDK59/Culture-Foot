import Link from "next/link";
import { getPlayerFromDb } from "@/lib/data/player-db";
import PlayerStatsEvolution from "@/components/PlayerStatsEvolution";
import CultureFootEraContext from "@/components/CultureFootEraContext";

const tabs = [
  ["Vue D’ensemble", "#overview"], ["Carrière", "#career"], ["Palmarès", "#honours"],
  ["Statistiques", "#stats"], ["Matchs", "#matches"], ["Transferts", "#transfers"],
  ["Analyses", "#analyses"], ["Multimédia", "#media"],
];

const discovery = [
  ["Clubs", "/recherche?q=Paris%20Saint-Germain"],
  ["Stades", "/stades/parc-des-princes"],
  ["Championnats", "/recherche?q=Ligue%201"],
  ["Histoire", "/recherche?q=Histoire%20du%20football"],
  ["Transferts", "/comparateur"],
  ["Économie", "/recherche?q=%C3%89conomie%20du%20football"],
];

export default async function PlayerPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const player = await getPlayerFromDb(slug);
  if (!player) return <main className="site-shell"><p className="eyebrow">Culture Foot</p><h1>Joueur Introuvable</h1><Link href="/">Retour À L’Accueil</Link></main>;

  const stats = player.seasonStats.filter(s => s.goals !== null || s.appearances !== null);
  const totalGoals = player.seasonMetrics.reduce((n, s) => n + (s.goals ?? 0), 0);
  const latestStat = stats[0];
  const evolutionMetrics = player.seasonMetrics.map((s) => ({
    id: s.id, key: s.key,
    season: { id: s.season.id, name: s.season.name, startDate: s.season.startDate?.toISOString() ?? null },
    club: s.club ? { id: s.club.id, name: s.club.name } : null,
    competition: s.competition ? { id: s.competition.id, name: s.competition.name, slug: s.competition.slug } : null,
    nationalTeam: s.nationalTeam ? { id: s.nationalTeam.id, name: s.nationalTeam.name, code: s.nationalTeam.code } : null,
    appearances: s.appearances, goals: s.goals, assists: s.assists, minutes: s.minutes, evidenceStatus: s.evidenceStatus, definition: s.definition,
  }));
  const clubs = [...new Map(player.spells.map(s => [s.club.id, s.club])).values()];

  return <main className="player-page">
    <header className="player-header"><Link href="/" className="brand">CULTURE FOOT</Link><div className="search">⌕ Rechercher Dans Le Football</div></header>
    <section className="player-hero" id="overview"><div className="rings" aria-hidden="true"/><div className="player-hero-content">
      <div className="eyebrow">Joueur · {player.nationalityCode ?? "—"} · {player.position ?? "—"}</div>
      <h1>{player.person.displayName}</h1>
      <div className="player-meta"><span>{player.currentClub?.name ?? "Club Inconnu"}</span><span>{player.nationalityCode ?? "—"}</span><span>{new Intl.DateTimeFormat("fr-FR", { dateStyle: "long" }).format(player.person.birthDate ?? new Date())}</span></div>
    </div></section>
    <nav className="player-tabs" aria-label="Navigation Joueur">{tabs.map(([label, href], i) => <a key={href} href={href} className={i===0?"active":""}>{label}</a>)}</nav>
    <div className="player-content">
      <section className="cf-section" id="career"><h2>Son Parcours</h2><div className="cf-grid">
        <article className="cf-card cf-card-large"><div className="cf-label">Clubs Référencés</div><div className="cf-value">{clubs.length}</div><p className="cf-muted">Chaque étape est reliée à son club, ses saisons et ses compétitions.</p></article>
        <article className="cf-card cf-card-side"><div className="cf-label">Club Actuel</div><div className="cf-value cf-value-text">{player.currentClub?.name ?? "—"}</div><p className="cf-muted">Une relation vivante dans le graphe Culture Foot.</p></article>
      </div></section>
      <section className="cf-section" id="honours"><h2>Son Palmarès</h2><div className="cf-grid"><article className="cf-card"><div className="cf-label">Distinctions Référencées</div><div className="cf-value">{player.honours.length}</div></article><article className="cf-card"><div className="cf-label">Sources Associées</div><div className="cf-value">{new Set(player.honours.map(h=>h.sourceId).filter(Boolean)).size}</div></article></div></section>
      <section className="cf-section" id="stats"><h2>Ses Données</h2><div className="cf-grid">
        <article className="cf-card cf-card-large"><div className="cf-label">Buts Ligue 1 Référencés</div><div className="cf-value">{totalGoals}</div><p className="cf-muted">Somme des observations actuellement chargées dans Culture Foot.</p></article>
        <article className="cf-card cf-card-side"><div className="cf-label">Dernière Observation</div><div className="cf-value">{latestStat?.goals ?? "—"}</div><p className="cf-muted">{latestStat ? `${latestStat.season.name} · ${latestStat.club?.name ?? "Club Inconnu"}` : "Aucune observation"}</p></article>
      </div></section>
      <section className="cf-section"><PlayerStatsEvolution metrics={evolutionMetrics} /></section>
      <CultureFootEraContext type="player" id={player.person.slug} label={player.person.displayName} />
      <section className="cf-section"><h2>Son Graphe Footballistique</h2><div className="graph-path"><div className="graph-node graph-player">{player.person.displayName}</div><div className="graph-arrow">→</div>{clubs.map(club=><Link className="graph-node graph-club" href={`/clubs/${club.slug}`} key={club.id}>{club.name}</Link>)}{player.currentClub?.stadiums.map(stadium=><Link className="graph-node graph-stadium" href={`/stades/${stadium.slug}`} key={stadium.id}>{stadium.name}</Link>)}</div><p className="cf-muted">Le graphe propose des portes d’exploration. Il ne remplace jamais votre recherche.</p></section>
      <section className="cf-section" id="matches"><h2>Ses Matchs</h2><div className="cf-grid">{player.appearances.length ? player.appearances.map(a => <Link href="#overview" className="cf-card cf-match-card" key={a.id}><div className="cf-label">{a.match.competition?.name ?? "Compétition"} · {a.match.season?.name ?? "Saison"}</div><div className="cf-value cf-value-text">{a.match.homeClub.name} {a.match.homeScore ?? "—"} — {a.match.awayScore ?? "—"} {a.match.awayClub.name}</div><p className="cf-muted">{a.match.stadium?.name ?? "Stade Inconnu"} · {a.started ? "Titulaire" : "Entré En Jeu / Présent Dans La Feuille"}</p></Link>) : <article className="cf-card"><div className="cf-label">Aucun Match Référencé</div><p className="cf-muted">Les matchs seront reliés ici au Joueur, au Club, au Stade, à la Compétition et aux événements.</p></article>}</div></section>
      <section className="cf-section" id="transfers"><h2>Ses Transferts</h2><div className="cf-card"><div className="cf-label">Historique Des Mouvements</div><p className="cf-muted">Montant, date, type, clubs, statut de preuve et source seront historisés séparément.</p></div></section>
      <section className="cf-section" id="analyses"><h2>Continuez Votre Voyage</h2><div className="discovery">{discovery.map(([label, href])=><Link href={href} key={label}><span className="discovery-icon" aria-hidden="true">↗</span><span className="discovery-label">{label}</span></Link>)}</div></section>
      <section className="cf-section" id="media"><h2>Sources</h2><div className="cf-card"><div className="cf-label">Provenance Des Données</div><p className="cf-muted">Chaque observation statistique conserve sa source et son niveau de preuve. Les données ne sont pas mélangées avec des valeurs inventées ou non vérifiées.</p></div></section>
    </div>
  </main>;
}

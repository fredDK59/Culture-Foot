import type { MetadataRoute } from 'next'

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000'
  const routes = [
    '/', '/recherche', '/joueurs', '/clubs', '/championnats', '/matchs',
    '/stades', '/transferts', '/economie', '/geographie', '/analyses',
    '/comparateur', '/sondages', '/jeux', '/communaute', '/parcours',
    '/v20',
  ]
  return routes.map((route) => ({ url: `${base.replace(/\/$/, '')}${route}` }))
}

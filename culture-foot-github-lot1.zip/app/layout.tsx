import "./globals.css";

export const metadata = {
  title: "Culture Foot",
  description: "Le Football Du Passé, Du Présent Et Du Futur."
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
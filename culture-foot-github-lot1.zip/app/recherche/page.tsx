import CultureFootKnowledgeSearch from '@/components/CultureFootKnowledgeSearch';

export default function RecherchePage() {
  return (
    <main className="min-h-screen bg-[#030914] px-5 py-10 md:px-10">
      <div className="mx-auto max-w-6xl">
        <header className="mb-10">
          <p className="text-sm font-black tracking-[0.3em] text-sky-400">
            CULTURE FOOT
          </p>
          <h1 className="mt-3 text-4xl font-black text-white md:text-6xl">
            Recherche
          </h1>
        </header>

        <CultureFootKnowledgeSearch />
      </div>
    </main>
  );
}

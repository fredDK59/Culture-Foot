import CultureFootSearchCompare from '@/components/CultureFootSearchCompare';

export default function ComparateurPage() {
  return (
    <main className="min-h-screen bg-[#030914] px-5 py-10 text-sky-100 md:px-10">
      <div className="mx-auto max-w-6xl">
        <header className="mb-10">
          <p className="text-sm font-black tracking-[0.3em] text-sky-400">
            CULTURE FOOT
          </p>
          <h1 className="mt-3 text-4xl font-black text-white md:text-6xl">
            Comparateur
          </h1>
          <p className="mt-3 max-w-2xl text-sky-200/60">
            Comparez Les Données Footballistiques Dans Un Cadre Comparable,
            Avec Leurs Définitions Et Leurs Sources.
          </p>
        </header>

        <CultureFootSearchCompare />
      </div>
    </main>
  );
}

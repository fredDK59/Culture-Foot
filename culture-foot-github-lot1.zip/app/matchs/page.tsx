export const dynamic = "force-dynamic";
export const revalidate = 0;
import Link from 'next/link';
import { db } from '@/lib/db';

export default async function MatchesPage() {
  const matches = await db.match.findMany({ orderBy: { kickoffAt: 'desc' }, take: 50, include: { homeClub: true, awayClub: true, stadium: true, competition: true } });
  return <main className="player-page"><header className="player-header"><Link href="/" className="brand">CULTURE FOOT</Link><div className="search">⌕ Rechercher Dans Le Football</div></header><section className="player-hero"><div className="rings" aria-hidden="true"/><div className="player-hero-content"><div className="eyebrow">Univers · Matchs</div><h1>Les Matchs</h1><div className="player-meta"><span>{matches.length} matchs dans l'instantané</span><span>Résultats · Stades · Compétitions</span></div></div></section><div className="player-content"><section className="cf-section"><h2>Derniers Matchs Référencés</h2><div className="cf-grid">{matches.map(match=><article className="cf-card cf-card-third" key={match.id}><div className="cf-label">{match.competition?.name ?? 'Compétition'} · {match.kickoffAt ? new Intl.DateTimeFormat('fr-FR',{dateStyle:'medium'}).format(match.kickoffAt) : 'Date inconnue'}</div><div className="cf-value cf-value-text">{match.homeClub.name} {match.homeScore ?? '—'} — {match.awayScore ?? '—'} {match.awayClub.name}</div><p className="cf-muted">{match.stadium?.name ?? 'Stade non renseigné'}</p></article>)}</div></section></div></main>;
}

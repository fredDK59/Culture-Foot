export const dynamic = "force-dynamic";
export const revalidate = 0;
import Link from 'next/link';
import { db } from '@/lib/db';

export default async function TransfersPage() {
  const transfers = await db.transfer.findMany({ orderBy: { transferDate: 'desc' }, take: 50, include: { player: { include: { person: true } }, fromClub: true, toClub: true, source: true } });
  return <main className="player-page"><header className="player-header"><Link href="/" className="brand">CULTURE FOOT</Link><div className="search">⌕ Rechercher Dans Le Football</div></header><section className="player-hero"><div className="rings" aria-hidden="true"/><div className="player-hero-content"><div className="eyebrow">Univers · Transferts</div><h1>Le Mercato</h1><div className="player-meta"><span>{transfers.length} mouvements référencés</span><span>Montants · Sources · Historique</span></div></div></section><div className="player-content"><section className="cf-section"><h2>Derniers Mouvements</h2><div className="cf-grid">{transfers.map(transfer=><Link className="cf-card cf-card-third" href={`/joueurs/${transfer.player.person.slug}`} key={transfer.id}><div className="cf-label">{transfer.transferDate ? new Intl.DateTimeFormat('fr-FR',{dateStyle:'medium'}).format(transfer.transferDate) : 'Date inconnue'} · {transfer.evidence}</div><div className="cf-value cf-value-text">{transfer.player.person.displayName}</div><p className="cf-muted">{transfer.fromClub?.name ?? '—'} → {transfer.toClub?.name ?? '—'} · {transfer.amountCents ? `${Number(transfer.amountCents)/100000000} €` : 'Montant non renseigné'}</p></Link>)}</div></section></div></main>;
}

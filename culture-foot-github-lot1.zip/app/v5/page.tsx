import Link from 'next/link'

const stages = [
  ['V5', 'Produit Solide', 'Consolidation, contrats canoniques, qualité et UX.', '/api/v5/health'],
  ['V6', 'Données Vivantes', 'Ingestion, historisation, anomalies et provenance.', '/api/v6/sources'],
  ['V7', 'Mémoire Du Football', 'Médias, archives, documents et contexte.', '/api/v7/media'],
  ['V8', 'Machine Temporelle', 'Saisons, époques, snapshots et contexte historique.', '/api/v8/time-machine'],
  ['V9', 'Football Intelligence', 'Analyses reproductibles, comparaisons et indicateurs.', '/api/v9/analyses'],
  ['V10', 'Culture Foot Public', 'Readiness, sécurité, performance et gouvernance.', '/api/v10/readiness'],
]

export default function V5Page() {
  return (
    <main className="site-shell">
      <header className="site-header"><Link className="brand" href="/">CULTURE FOOT</Link><span className="eyebrow">V5 → V10</span></header>
      <section className="home-hero" style={{ minHeight: 'auto', padding: '90px 0 60px' }}>
        <div className="eyebrow">Une Seule Architecture</div>
        <h1>Du Prototype<br /><em>Au Produit Footballistique.</em></h1>
        <p className="hero-copy">V5 consolide. V6 alimente. V7 mémorise. V8 voyage dans le temps. V9 analyse. V10 ouvre au public.</p>
      </section>
      <section className="v2-section">
        <div className="v2-grid">
          {stages.map(([version, title, text, href]) => <article className="v2-card" key={version}>
            <span className="v2-tag">{version}</span><h2>{title}</h2><p>{text}</p><Link href={href}>Contrat / endpoint →</Link>
          </article>)}
        </div>
      </section>
      <section className="v2-section spotlight"><div className="v2-kicker">Suite</div><h2>V11 → V13</h2><p>Le Premier Vrai Culture Foot, Le Moteur De Curiosité Et Le Passage À Grande Échelle.</p><Link href="/v13">Ouvrir V11 → V13 →</Link></section><section className="v2-section curiosity-band"><div><div className="v2-kicker">Principe</div><h2>Le Contenu Répond. Le Design Intrigue. La Navigation Propose. Le Visiteur Décide.</h2></div></section>
    </main>
  )
}

import Link from 'next/link'
import { canonicalCatalog } from '@/lib/v11/catalog'

const stages = [
  ['V11','Le Premier Vrai Culture Foot','Produit réel : accueil, pages canoniques, données, navigation et mobile-first.'],
  ['V12','Le Moteur De Curiosité','Une réponse claire, puis des portes facultatives vers d’autres connaissances.'],
  ['V13','Le Football À Grande Échelle','Catalogue canonique, couverture mondiale, médias, archives et préparation production.'],
]

export default function V13Page() {
  return <main className="site-shell">
    <header className="site-header"><Link className="brand" href="/">CULTURE FOOT</Link><nav><Link href="/recherche">Recherche</Link><Link href="/analyses">Analyses</Link><Link href="/parcours">Mon Parcours</Link></nav><span className="eyebrow">V11 → V13</span></header>
    <section className="home-hero" style={{minHeight:'auto',padding:'86px 0 56px'}}>
      <div className="eyebrow">Une Seule Trajectoire</div>
      <h1>Le Produit.<br/><em>La Curiosité. L’Univers.</em></h1>
      <p className="hero-copy">V11 rend Culture Foot utilisable. V12 transforme chaque réponse en point de départ. V13 prépare la couverture footballistique à grande échelle.</p>
      <div className="home-actions"><Link className="primary-button" href="/recherche">Chercher</Link><Link className="secondary-button" href="/geographie">Explorer</Link><Link className="secondary-button" href="/jeux">Étonnez-Moi</Link></div>
    </section>
    <section className="v2-section"><div className="v2-grid">{stages.map(([v,t,d])=><article className="v2-card" key={v}><span className="v2-tag">{v}</span><h2>{t}</h2><p>{d}</p></article>)}</div></section>
    <section className="v2-section"><div className="section-head"><div><div className="v2-kicker">Catalogue Canonique</div><h2>Les Premières Portes</h2></div><Link href="/recherche">Recherche →</Link></div><div className="v2-grid">{canonicalCatalog.map(e=><Link className="v2-card" href={e.href} key={e.id}><span className="v2-tag">{e.type}</span><h3>{e.label}</h3><p>{e.subtitle}</p><small>{e.tags.join(' · ')}</small></Link>)}</div></section>
    <section className="v2-section curiosity-band"><div><div className="v2-kicker">Moteur De Curiosité</div><h2>Intention → Réponse → Curiosités Possibles → Choix</h2><p className="v2-muted">Culture Foot Propose. Le Visiteur Dispose.</p></div></section>
    <section className="v2-section spotlight"><div className="v2-kicker">V11 → V13</div><h2>Le Contenu Répond. Le Design Intrigue. La Navigation Propose. Le Visiteur Décide.</h2><p className="v2-muted">Les trois versions forment maintenant un même produit, pas trois projets séparés.</p></section>
  </main>
}

import { CultureFootV4Hub } from '@/components/v4/CultureFootV4Hub'

export default function V4Page() {
  return <CultureFootV4Hub />
}

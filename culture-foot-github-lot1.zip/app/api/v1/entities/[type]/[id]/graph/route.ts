import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

type Params = { type: string; id: string };

type GraphNode = {
  id: string;
  type: string;
  label: string;
  depth: number;
  relationTypes: string[];
};

type GraphRelation = {
  from: { type: string; id: string };
  to: { type: string; id: string };
  type: string;
  depth: number;
};

function parseDepth(request: Request) {
  const value = new URL(request.url).searchParams.get('depth');
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.min(2, Math.max(1, Math.floor(parsed))) : 1;
}

export async function GET(
  request: Request,
  { params }: { params: Promise<Params> }
) {
  const { type, id } = await params;
  const maxDepth = parseDepth(request);

  const allRelations = await db.entityRelation.findMany({
    orderBy: { relationType: 'asc' },
  });

  const startKey = `${type}:${id}`;
  const nodes = new Map<string, GraphNode>();
  const relations: GraphRelation[] = [];

  nodes.set(startKey, {
    id,
    type,
    label: id,
    depth: 0,
    relationTypes: [],
  });

  let frontier = [startKey];
  const visited = new Set([startKey]);

  for (let depth = 1; depth <= maxDepth; depth += 1) {
    const nextFrontier: string[] = [];

    for (const key of frontier) {
      const separator = key.indexOf(':');
      const currentType = key.slice(0, separator);
      const currentId = key.slice(separator + 1);

      for (const relation of allRelations) {
        const isFrom =
          relation.fromType === currentType && relation.fromId === currentId;
        const isTo =
          relation.toType === currentType && relation.toId === currentId;

        if (!isFrom && !isTo) continue;

        const otherType = isFrom ? relation.toType : relation.fromType;
        const otherId = isFrom ? relation.toId : relation.fromId;
        const otherKey = `${otherType}:${otherId}`;

        if (!nodes.has(otherKey)) {
          nodes.set(otherKey, {
            id: otherId,
            type: otherType,
            label: otherId,
            depth,
            relationTypes: [relation.relationType],
          });
        } else {
          const node = nodes.get(otherKey)!;
          if (!node.relationTypes.includes(relation.relationType)) {
            node.relationTypes.push(relation.relationType);
          }
          node.depth = Math.min(node.depth, depth);
        }

        const relationExists = relations.some(
          (r) =>
            r.from.type === relation.fromType &&
            r.from.id === relation.fromId &&
            r.to.type === relation.toType &&
            r.to.id === relation.toId &&
            r.type === relation.relationType
        );

        if (!relationExists) {
          relations.push({
            from: { type: relation.fromType, id: relation.fromId },
            to: { type: relation.toType, id: relation.toId },
            type: relation.relationType,
            depth,
          });
        }

        if (!visited.has(otherKey)) {
          visited.add(otherKey);
          nextFrontier.push(otherKey);
        }
      }
    }

    frontier = nextFrontier;
  }

  return NextResponse.json({
    center: { type, id },
    depth: maxDepth,
    nodes: Array.from(nodes.values()),
    relations,
    count: relations.length,
    temporal: {
      enabled: true,
      principle: 'Une Relation Peut Être Explorée Dans Son Contexte Temporel.',
    },
  });
}

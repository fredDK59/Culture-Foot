import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ type: string; id: string }> }
) {
  const { type, id } = await params;

  const events: Array<{
    date: string;
    kind: string;
    label: string;
    hrefType: string;
    hrefId: string;
  }> = [];

  if (type === 'player' || type === 'players') {
    const player = await db.player.findFirst({
      where: { person: { slug: id } },
      include: {
        spells: {
          include: { club: true },
          orderBy: { startDate: 'asc' },
        },
        honours: true,
      },
    });

    if (player) {
      for (const spell of player.spells) {
        events.push({
          date: spell.startDate?.toISOString().slice(0, 10) ?? 'UNKNOWN',
          kind: 'CLUB_SPELL',
          label: spell.club.name,
          hrefType: 'club',
          hrefId: spell.club.slug,
        });
      }

      for (const honour of player.honours) {
        events.push({
          date: String(honour.year),
          kind: 'HONOUR',
          label: honour.title,
          hrefType: 'honour',
          hrefId: String(honour.id),
        });
      }
    }
  }

  events.sort((a, b) => a.date.localeCompare(b.date));

  return NextResponse.json({
    center: { type, id },
    events,
    principle: 'Le Temps Est Un Fil De Lecture, Pas Une Destination Imposée.',
  });
}

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ type: string; id: string }> }
) {
  const { type, id } = await params;

  const relations = await db.entityRelation.findMany({
    where: {
      OR: [
        { fromType: type, fromId: id },
        { toType: type, toId: id },
      ],
    },
    take: 20,
  });

  const suggestions = relations.map((r) => {
    const isFrom = r.fromType === type && r.fromId === id;
    return {
      type: isFrom ? r.toType : r.fromType,
      id: isFrom ? r.toId : r.fromId,
      relationType: r.relationType,
      reason: `Relié Par « ${r.relationType} »`,
    };
  });

  return NextResponse.json({
    center: { type, id },
    suggestions,
    principle: 'Suggestion facultative : le visiteur choisit son prochain chemin.',
  });
}

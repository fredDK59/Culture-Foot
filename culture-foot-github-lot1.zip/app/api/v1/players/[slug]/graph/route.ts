import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(_: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const player = await db.player.findFirst({
    where: { person: { slug } },
    include: {
      person: true,
      currentClub: { include: { stadiums: true } },
      spells: { include: { club: { include: { stadiums: true } } }, orderBy: { startDate: "asc" } },
      seasonStats: { include: { season: { include: { competition: true } }, club: true, source: true }, orderBy: { observedAt: "desc" } },
      appearances: { include: { match: { include: { homeClub: true, awayClub: true, stadium: true, competition: true } } } },
    },
  });
  if (!player) return NextResponse.json({ error: "Player not found" }, { status: 404 });
  const nodes = new Map<string, { id: string; type: string; label: string; slug?: string }>();
  const edges: { from: string; to: string; relation: string }[] = [];
  const add = (id:string,type:string,label:string,slug?:string) => nodes.set(`${type}:${id}`, {id,type,label,slug});
  add(player.id,"PLAYER",player.person.displayName,player.person.slug);
  for (const spell of player.spells) {
    add(spell.club.id,"CLUB",spell.club.name,spell.club.slug);
    edges.push({from:`PLAYER:${player.id}`,to:`CLUB:${spell.club.id}`,relation:"a joué pour"});
    for (const stadium of spell.club.stadiums) {
      add(stadium.id,"STADIUM",stadium.name,stadium.slug);
      edges.push({from:`CLUB:${spell.club.id}`,to:`STADIUM:${stadium.id}`,relation:"joue au"});
    }
  }
  for (const appearance of player.appearances) {
    const match = appearance.match;
    add(match.id, "MATCH", `${match.homeClub.name} ${match.homeScore ?? "—"} — ${match.awayScore ?? "—"} ${match.awayClub.name}`);
    edges.push({ from: `PLAYER:${player.id}`, to: `MATCH:${match.id}`, relation: "a participé à" });
    add(match.homeClub.id, "CLUB", match.homeClub.name, match.homeClub.slug);
    add(match.awayClub.id, "CLUB", match.awayClub.name, match.awayClub.slug);
    edges.push({ from: `MATCH:${match.id}`, to: `CLUB:${match.homeClub.id}`, relation: "équipe à domicile" });
    edges.push({ from: `MATCH:${match.id}`, to: `CLUB:${match.awayClub.id}`, relation: "équipe à l'extérieur" });
    if (match.stadium) {
      add(match.stadium.id, "STADIUM", match.stadium.name, match.stadium.slug);
      edges.push({ from: `MATCH:${match.id}`, to: `STADIUM:${match.stadium.id}`, relation: "s'est joué à" });
    }
    if (match.competition) {
      add(match.competition.id, "COMPETITION", match.competition.name, match.competition.slug);
      edges.push({ from: `MATCH:${match.id}`, to: `COMPETITION:${match.competition.id}`, relation: "compétition" });
    }
  }
  for (const stat of player.seasonStats) {
    add(stat.season.competition.id,"COMPETITION",stat.season.competition.name,stat.season.competition.slug);
    edges.push({from:`PLAYER:${player.id}`,to:`COMPETITION:${stat.season.competition.id}`,relation:"a évolué en"});
    if (stat.club) {
      add(stat.club.id,"CLUB",stat.club.name,stat.club.slug);
      edges.push({from:`PLAYER:${player.id}`,to:`CLUB:${stat.club.id}`,relation:"statistiques avec"});
    }
  }
  return NextResponse.json({ nodes:[...nodes.values()], edges });
}

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

function serialise(value: unknown): unknown {
  if (typeof value === 'bigint') return Number(value);
  if (value && typeof value === 'object' && 'toString' in value) {
    const name = Object.prototype.toString.call(value);
    if (name === '[object Decimal]') return Number((value as { toString(): string }).toString());
  }
  return value;
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const { searchParams } = new URL(request.url);

  const scope = searchParams.get('scope') ?? 'LIGUE_1';
  const metric = searchParams.get('metric') ?? 'GOALS';

  const player = await db.player.findFirst({
    where: { person: { slug } },
    select: { id: true },
  });

  if (!player) {
    return NextResponse.json({ error: 'PLAYER_NOT_FOUND' }, { status: 404 });
  }

  const rows = await db.playerSeasonMetric.findMany({
    where: {
      playerId: player.id,
      ...(scope === 'FRANCE'
        ? { nationalTeamId: { not: null } }
        : scope === 'LIGUE_1'
          ? { competition: { name: 'Ligue 1' } }
          : {}),
    },
    include: {
      season: true,
      competition: true,
      club: true,
      nationalTeam: true,
    },
    orderBy: { season: { startDate: 'asc' } },
  });

  const data = rows.map((row) => ({
    season: row.season.name,
    competition: row.competition?.name ?? null,
    club: row.club?.name ?? null,
    nationalTeam: row.nationalTeam?.name ?? null,
    metric,
    value: serialise(
      metric === 'APPEARANCES' ? row.appearances :
      metric === 'MINUTES' ? row.minutes :
      metric === 'ASSISTS' ? row.assists :
      row.goals
    ),
    evidenceStatus: row.evidenceStatus,
    sourceId: row.sourceId ?? null,
    sourceDate: row.sourceDate ?? null,
    definition: row.definition ?? null,
  }));

  return NextResponse.json({
    player: slug,
    scope,
    metric,
    data,
    methodology: {
      scope,
      metric,
      note: 'Les périmètres sont conservés séparément afin d’éviter les comparaisons de données incompatibles.',
    },
  });
}

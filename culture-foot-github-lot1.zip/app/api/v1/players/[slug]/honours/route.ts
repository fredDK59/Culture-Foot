import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const player = await db.player.findFirst({
    where: { person: { slug } },
    include: {
      honours: true,
      nationalTeams: { include: { nationalTeam: true } },
    },
  });

  if (!player) return NextResponse.json({ error: "Player not found" }, { status: 404 });

  return NextResponse.json({
    player: { id: player.id, slug: player.person.slug, name: player.person.displayName },
    honours: player.honours,
    nationalTeams: player.nationalTeams.map((x) => ({
      name: x.nationalTeam.name,
      code: x.nationalTeam.code,
      startDate: x.startDate,
      endDate: x.endDate,
      role: x.role,
      evidenceStatus: x.evidenceStatus,
    })),
  });
}

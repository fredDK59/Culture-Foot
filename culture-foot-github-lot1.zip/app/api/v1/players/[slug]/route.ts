import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;

  const player = await db.player.findFirst({
    where: {
      person: { slug },
    },
    include: {
      person: true,
      currentClub: true,
      spells: {
        include: { club: true },
        orderBy: { startDate: "asc" },
      },
      seasonStats: {
        include: { season: true, club: true, source: true },
        orderBy: { observedAt: "desc" },
      },
      marketValues: {
        include: { source: true },
        orderBy: { observedAt: "desc" },
      },
      honours: {
        include: { source: true },
      },
    },
  });

  if (!player) {
    return NextResponse.json(
      { error: "PLAYER_NOT_FOUND" },
      { status: 404 }
    );
  }

  return NextResponse.json(JSON.parse(JSON.stringify(player, (_, value) => typeof value === "bigint" ? value.toString() : value)));
}
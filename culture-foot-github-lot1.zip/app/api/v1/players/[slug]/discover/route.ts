import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;

  const player = await db.player.findFirst({
    where: { person: { slug } },
    select: { id: true, person: { select: { displayName: true } } },
  });

  if (!player) {
    return NextResponse.json({ error: "PLAYER_NOT_FOUND" }, { status: 404 });
  }

  const relations = await db.entityRelation.findMany({
    where: {
      fromType: "PLAYER",
      fromId: player.id,
    },
    orderBy: [{ weight: "desc" }, { relationType: "asc" }],
    take: 12,
  });

  return NextResponse.json({
    subject: player.person.displayName,
    principle: "Culture Foot Propose. Le Visiteur Dispose.",
    recommendations: relations,
  });
}
import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(_: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const stadium = await db.stadium.findUnique({ where: { slug }, include: { club: true } });
  if (!stadium) return NextResponse.json({ error: "Stadium not found" }, { status: 404 });
  return NextResponse.json(JSON.parse(JSON.stringify(stadium, (_, v) => typeof v === "bigint" ? v.toString() : v)));
}

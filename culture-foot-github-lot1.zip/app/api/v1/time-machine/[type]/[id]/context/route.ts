import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

function parseYear(value: string | null) {
  if (!value) return null;
  const year = Number(value);
  return Number.isInteger(year) && year >= 1800 && year <= 2200 ? year : null;
}

function serialise(value: unknown): unknown {
  if (typeof value === 'bigint') return Number(value);
  if (value && typeof value === 'object' && 'toString' in value) {
    const tag = Object.prototype.toString.call(value);
    if (tag === '[object Decimal]') return Number((value as { toString(): string }).toString());
  }
  return value;
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ type: string; id: string }> }
) {
  const { type, id } = await params;
  const year = parseYear(new URL(request.url).searchParams.get('year'));

  if (!year) {
    return NextResponse.json({ error: 'Paramètre year requis, entre 1800 et 2200.' }, { status: 400 });
  }

  const start = new Date(`${year}-01-01T00:00:00.000Z`);
  const end = new Date(`${year}-12-31T23:59:59.999Z`);

  if (type !== 'player' && type !== 'players') {
    return NextResponse.json(
      { error: `Contexte temporel détaillé non disponible pour le type ${type}.` },
      { status: 400 },
    );
  }

  const player = await db.player.findFirst({
    where: { person: { slug: id } },
    include: {
      person: true,
      spells: { include: { club: true }, where: { startDate: { lte: end }, OR: [{ endDate: { gte: start } }, { endDate: null }] } },
      seasonMetrics: {
        where: { season: { startDate: { lte: end }, endDate: { gte: start } } },
        include: { season: true, competition: true, club: true, nationalTeam: true, source: true },
        orderBy: { season: { startDate: 'asc' } },
      },
      honours: { where: { year }, include: { source: true, nationalTeam: true } },
      transfers: {
        where: { transferDate: { gte: start, lte: end } },
        include: { fromClub: true, toClub: true, source: true },
        orderBy: { transferDate: 'asc' },
      },
    },
  });

  if (!player) return NextResponse.json({ error: 'Joueur introuvable.' }, { status: 404 });

  const clubIds = player.spells.map((spell) => spell.clubId);
  const matches = clubIds.length
    ? await db.match.findMany({
        where: {
          kickoffAt: { gte: start, lte: end },
          OR: [{ homeClubId: { in: clubIds } }, { awayClubId: { in: clubIds } }],
        },
        include: { homeClub: true, awayClub: true, stadium: true, competition: true, season: true },
        orderBy: { kickoffAt: 'asc' },
        take: 50,
      })
    : [];

  const stadiumIds = [...new Set(matches.map((match) => match.stadiumId).filter(Boolean) as string[])];
  const stadiums = stadiumIds.length
    ? await db.stadium.findMany({ where: { id: { in: stadiumIds } }, include: { club: true } })
    : [];

  const relations = await db.entityRelation.findMany({
    where: {
      OR: [
        { fromType: 'PLAYER', fromId: player.id },
        { toType: 'PLAYER', toId: player.id },
      ],
      AND: [
        { OR: [{ validFrom: null }, { validFrom: { lte: end } }] },
        { OR: [{ validTo: null }, { validTo: { gte: start } }] },
      ],
    },
    orderBy: { relationType: 'asc' },
  });

  return NextResponse.json({
    center: { type: 'player', id: player.person.slug, label: player.person.displayName },
    year,
    period: { start, end },
    clubs: player.spells.map((spell) => ({
      id: spell.club.slug,
      name: spell.club.name,
      startDate: spell.startDate,
      endDate: spell.endDate,
    })),
    metrics: player.seasonMetrics.map((metric) => ({
      season: metric.season.name,
      competition: metric.competition?.name ?? null,
      club: metric.club?.name ?? null,
      nationalTeam: metric.nationalTeam?.name ?? null,
      appearances: metric.appearances,
      goals: metric.goals,
      assists: metric.assists,
      minutes: metric.minutes,
      xg: serialise(metric.xg),
      xa: serialise(metric.xa),
      evidenceStatus: metric.evidenceStatus,
      source: metric.source ? { name: metric.source.name, url: metric.source.url } : null,
      definition: metric.definition,
    })),
    honours: player.honours.map((honour) => ({
      title: honour.title,
      team: honour.team,
      year: honour.year,
      evidenceStatus: honour.evidenceStatus,
      source: honour.source ? { name: honour.source.name, url: honour.source.url } : null,
    })),
    transfers: player.transfers.map((transfer) => ({
      date: transfer.transferDate,
      type: transfer.transferType,
      from: transfer.fromClub?.name ?? null,
      to: transfer.toClub?.name ?? null,
      amountCents: serialise(transfer.amountCents),
      currency: transfer.currency,
      evidenceStatus: transfer.evidence,
      source: transfer.source ? { name: transfer.source.name, url: transfer.source.url } : null,
    })),
    matches: matches.map((match) => ({
      id: match.id,
      date: match.kickoffAt,
      home: match.homeClub.name,
      away: match.awayClub.name,
      score: `${match.homeScore ?? '—'} — ${match.awayScore ?? '—'}`,
      stadium: match.stadium?.name ?? null,
      competition: match.competition?.name ?? null,
      season: match.season?.name ?? null,
    })),
    stadiums: stadiums.map((stadium) => ({
      id: stadium.slug,
      name: stadium.name,
      city: stadium.city,
      capacity: stadium.capacity,
      club: stadium.club?.name ?? null,
    })),
    relations: relations.map((relation) => ({
      relationType: relation.relationType,
      from: { type: relation.fromType, id: relation.fromId },
      to: { type: relation.toType, id: relation.toId },
      evidenceStatus: relation.evidence,
    })),
    limitations: [
      'Seules les données présentes et documentées dans la base sont affichées.',
      'Une absence de donnée ne signifie pas une absence historique.',
      'Les montants ou métriques estimés conservent leur statut de preuve.',
      'Les périmètres statistiques restent séparés pour éviter les comparaisons incompatibles.',
    ],
    principle: 'Contexte D’Époque : Replacer Un Sujet Dans Son Environnement Documenté, Sans Inventer Ce Qui Manque.',
  });
}

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

function validYear(value: string | null) {
  if (!value) return null;
  const n = Number(value);
  return Number.isInteger(n) && n >= 1800 && n <= 2200 ? n : null;
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ type: string; id: string }> }
) {
  const { type, id } = await params;
  const url = new URL(request.url);
  const year = validYear(url.searchParams.get('year'));

  if (!year) {
    return NextResponse.json(
      { error: 'Paramètre year requis, entre 1800 et 2200.' },
      { status: 400 }
    );
  }

  const start = new Date(`${year}-01-01T00:00:00.000Z`);
  const end = new Date(`${year}-12-31T23:59:59.999Z`);

  if (type === 'player' || type === 'players') {
    const player = await db.player.findFirst({
      where: { person: { slug: id } },
      include: {
        person: true,
        spells: {
          include: { club: true },
          where: {
            OR: [
              { startDate: { lte: end }, endDate: { gte: start } },
              { startDate: { lte: end }, endDate: null },
            ],
          },
        },
        seasonMetrics: {
          where: {
            season: {
              startDate: { lte: end },
              endDate: { gte: start },
            },
          },
          include: { season: true, competition: true, club: true },
        },
      },
    });

    if (!player) {
      return NextResponse.json({ error: 'Joueur introuvable.' }, { status: 404 });
    }

    return NextResponse.json({
      center: {
        type: 'player',
        id,
        label: player.person?.displayName ?? id,
      },
      year,
      clubs: player.spells.map((spell) => ({
        id: spell.club.slug,
        name: spell.club.name,
        startDate: spell.startDate,
        endDate: spell.endDate,
      })),
      metrics: player.seasonMetrics.map((metric) => ({
        season: metric.season.name,
        competition: metric.competition?.name ?? null,
        club: metric.club?.name ?? null,
        appearances: metric.appearances,
        goals: metric.goals,
        assists: metric.assists,
        minutes: metric.minutes,
        evidenceStatus: metric.evidenceStatus,
      })),
      principle:
        'Une Entité Est Explorée Dans Le Contexte Temporel Choisi.',
    });
  }

  return NextResponse.json(
    { error: `Voyage temporel non disponible pour le type ${type}.` },
    { status: 400 }
  );
}

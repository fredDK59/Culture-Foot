import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

function parseYear(value: string | null) {
  if (!value) return null;
  const year = Number(value);
  return Number.isInteger(year) && year >= 1800 && year <= 2200 ? year : null;
}

function parseSeason(value: string | null) {
  if (!value || !/^\d{4}-\d{4}$/.test(value)) return null;
  return value;
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const year = parseYear(url.searchParams.get('year'));
  const seasonLabel = parseSeason(url.searchParams.get('season'));

  const seasons = await db.season.findMany({
    where: seasonLabel
      ? { name: seasonLabel }
      : year
        ? {
            startDate: { lte: new Date(`${year}-12-31T23:59:59.999Z`) },
            endDate: { gte: new Date(`${year}-01-01T00:00:00.000Z`) },
          }
        : undefined,
    include: {
      competition: true,
    },
    orderBy: { startDate: 'asc' },
    take: 25,
  });

  const seasonIds = seasons.map((season) => season.id);

  const matches = seasonIds.length
    ? await db.match.findMany({
        where: { seasonId: { in: seasonIds } },
        include: {
          homeClub: true,
          awayClub: true,
          stadium: true,
          competition: true,
        },
        orderBy: { kickoffAt: 'asc' },
        take: 50,
      })
    : [];

  const transfers = year
    ? await db.transfer.findMany({
        where: {
          transferDate: {
            gte: new Date(`${year}-01-01T00:00:00.000Z`),
            lte: new Date(`${year}-12-31T23:59:59.999Z`),
          },
        },
        include: {
          player: { include: { person: true } },
          fromClub: true,
          toClub: true,
        },
        take: 50,
      })
    : [];

  return NextResponse.json({
    request: {
      year,
      season: seasonLabel,
    },
    seasons: seasons.map((season) => ({
      id: season.id,
      label: season.name,
      competition: season.competition?.name ?? null,
    })),
    matches: matches.map((match) => ({
      id: match.id,
      date: match.kickoffAt?.toISOString() ?? null,
      home: match.homeClub?.name ?? null,
      away: match.awayClub?.name ?? null,
      stadium: match.stadium?.name ?? null,
      competition: match.competition?.name ?? null,
    })),
    transfers: transfers.map((transfer) => ({
      id: transfer.id,
      date: transfer.transferDate,
      player: transfer.player?.person?.slug ?? null,
      from: transfer.fromClub?.name ?? null,
      to: transfer.toClub?.name ?? null,
    })),
    principle:
      'La Machine Temporelle Reconstruit Un Contexte À Partir Des Données Disponibles.',
  });
}

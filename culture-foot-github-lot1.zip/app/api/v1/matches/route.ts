import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const clubSlug = url.searchParams.get("club");
  const playerSlug = url.searchParams.get("player");
  const matches = await db.match.findMany({
    where: {
      ...(clubSlug ? { OR: [{ homeClub: { slug: clubSlug } }, { awayClub: { slug: clubSlug } }] } : {}),
      ...(playerSlug ? { appearances: { some: { player: { person: { slug: playerSlug } } } } } : {}),
    },
    include: { homeClub: true, awayClub: true, stadium: true, competition: true, season: true },
    orderBy: { kickoffAt: "desc" },
    take: 50,
  });

  return NextResponse.json(matches.map(match => ({
    ...match,
    kickoffAt: match.kickoffAt?.toISOString() ?? null,
    createdAt: match.createdAt.toISOString(),
  })));
}

import { NextResponse } from "next/server";
import { db } from "@/lib/db";

function serialize(value: unknown): unknown {
  if (typeof value === "bigint") return value.toString();
  if (Array.isArray(value)) return value.map(serialize);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, serialize(v)]));
  }
  return value;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const playerId = searchParams.get("playerId");
  const transfers = await db.transfer.findMany({
    where: playerId ? { playerId } : undefined,
    include: { fromClub: true, toClub: true, source: true },
    orderBy: { transferDate: "asc" },
  });
  return NextResponse.json(serialize(transfers));
}

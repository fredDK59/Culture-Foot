import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

function normalise(input: string) {
  return input.trim().toLowerCase().replace(/\s+/g, ' ');
}

export async function GET(request: Request) {
  const raw = new URL(request.url).searchParams.get('q')?.trim() ?? '';
  const q = normalise(raw);

  if (!q) {
    return NextResponse.json({
      query: raw,
      results: [],
      intents: [],
      doors: [],
    });
  }

  const [players, clubs, competitions, stadiums] = await Promise.all([
    db.player.findMany({
      where: {
        OR: [
          { person: { slug: { contains: q } } },
          { person: { displayName: { contains: raw, mode: 'insensitive' } } },
        ],
      },
      take: 8,
      select: {
        person: { select: { slug: true, displayName: true } },
      },
    }),
    db.club.findMany({
      where: { name: { contains: raw, mode: 'insensitive' } },
      take: 8,
      select: { id: true, slug: true, name: true },
    }),
    db.competition.findMany({
      where: { name: { contains: raw, mode: 'insensitive' } },
      take: 8,
      select: { id: true, name: true },
    }),
    db.stadium.findMany({
      where: { name: { contains: raw, mode: 'insensitive' } },
      take: 8,
      select: { id: true, name: true, city: true, countryCode: true },
    }),
  ]);

  const results = [
    ...players.map((p) => ({
      type: 'PLAYER',
      slug: p.person.slug,
      name: p.person.displayName,
      description: 'Joueur',
      doors: ['PROFILE', 'STATS', 'MATCHES', 'TRANSFERS', 'COMPARE'],
    })),
    ...clubs.map((c) => ({
      type: 'CLUB',
      slug: c.slug,
      name: c.name,
      description: 'Club',
      doors: ['PROFILE', 'SQUAD', 'MATCHES', 'TRANSFERS', 'ECONOMY'],
    })),
    ...competitions.map((c) => ({
      type: 'COMPETITION',
      id: c.id,
      name: c.name,
      description: 'Compétition',
      doors: ['STANDINGS', 'CALENDAR', 'SCORERS', 'HISTORY', 'STATS'],
    })),
    ...stadiums.map((s) => ({
      type: 'STADIUM',
      id: s.id,
      name: s.name,
      description: `${s.city ?? ''}${s.countryCode ? ` · ${s.countryCode}` : ''}`.trim(),
      doors: ['PROFILE', 'HISTORY', 'MATCHES', 'GEOGRAPHY', 'CAPACITY'],
    })),
  ];

  const comparisonMatch = raw.match(/compare(?:r)?\s+(.+?)\s+(?:et|vs|contre)\s+(.+)/i);

  const intents = comparisonMatch
    ? [{
        type: 'PLAYER_COMPARISON',
        leftQuery: comparisonMatch[1].trim(),
        rightQuery: comparisonMatch[2].trim(),
        suggestedMetrics: ['GOALS', 'APPEARANCES', 'ASSISTS', 'MINUTES'],
      }]
    : [];

  const doors = results.slice(0, 6).map((r) => ({
    label: r.name,
    type: r.type,
    actions: r.doors,
  }));

  return NextResponse.json({
    query: raw,
    results,
    intents,
    doors,
    principle: 'La recherche ouvre des portes. Elle ne choisit pas le parcours.',
  });
}

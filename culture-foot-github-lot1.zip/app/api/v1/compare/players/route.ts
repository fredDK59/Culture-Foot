import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

function serialise(value: unknown): unknown {
  if (typeof value === 'bigint') return Number(value);
  if (value && typeof value === 'object' && 'toString' in value) {
    const tag = Object.prototype.toString.call(value);
    if (tag === '[object Decimal]') return Number((value as { toString(): string }).toString());
  }
  return value;
}

const metricField = {
  GOALS: 'goals',
  APPEARANCES: 'appearances',
  ASSISTS: 'assists',
  MINUTES: 'minutes',
} as const;

export async function GET(request: Request) {
  const url = new URL(request.url);
  const left = url.searchParams.get('left');
  const right = url.searchParams.get('right');
  const scope = url.searchParams.get('scope') ?? 'LIGUE_1';
  const metric = (url.searchParams.get('metric') ?? 'GOALS') as keyof typeof metricField;

  if (!left || !right || !metricField[metric]) {
    return NextResponse.json(
      { error: 'PARAMETERS_REQUIRED', required: ['left', 'right', 'metric'] },
      { status: 400 }
    );
  }

  const players = await db.player.findMany({
    where: { person: { slug: { in: [left, right] } } },
    select: { id: true, slug: true, person: { select: { displayName: true } } },
  });

  if (players.length !== 2) {
    return NextResponse.json({ error: 'PLAYER_NOT_FOUND' }, { status: 404 });
  }

  const ids = players.map((p) => p.id);

  const rows = await db.playerSeasonMetric.findMany({
    where: {
      playerId: { in: ids },
      ...(scope === 'FRANCE'
        ? { nationalTeamId: { not: null } }
        : scope === 'LIGUE_1'
          ? { competition: { name: 'Ligue 1' } }
          : {}),
    },
    include: {
      player: { include: { person: true } },
      season: true,
      competition: true,
      club: true,
      nationalTeam: true,
    },
    orderBy: { season: { startDate: 'asc' } },
  });

  const field = metricField[metric];

  const data = rows.map((row) => ({
    player: row.player.person.slug,
    playerName: row.player.person.displayName,
    season: row.season.name,
    competition: row.competition?.name ?? null,
    club: row.club?.name ?? null,
    nationalTeam: row.nationalTeam?.name ?? null,
    value: serialise(row[field]),
    evidenceStatus: row.evidenceStatus,
    sourceId: row.sourceId ?? null,
    sourceDate: row.sourceDate ?? null,
    definition: row.definition ?? null,
  }));

  return NextResponse.json({
    left,
    right,
    scope,
    metric,
    comparableByDesign: true,
    data,
    methodology: {
      rule: 'Comparaison effectuée uniquement sur des lignes partageant le même indicateur et le même périmètre.',
      missingValues: 'Une donnée absente reste absente et n’est pas remplacée automatiquement.',
      evidence: 'Le statut de preuve et la source restent attachés à chaque observation.',
    },
  });
}

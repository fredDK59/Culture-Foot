import { NextResponse } from 'next/server'
import { productContract } from '@/lib/v11/product'
export async function GET() { return NextResponse.json(productContract) }

import { NextRequest, NextResponse } from 'next/server'
import { buildSearchIntent } from '@/lib/v4/search'

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q') ?? ''
  return NextResponse.json({
    intent: buildSearchIntent(q, {
      entityTypes: req.nextUrl.searchParams.getAll('type'),
      country: req.nextUrl.searchParams.get('country') || undefined,
      seasonFrom: req.nextUrl.searchParams.get('from') || undefined,
      seasonTo: req.nextUrl.searchParams.get('to') || undefined,
    })
  })
}

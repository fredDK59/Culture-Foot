import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({
    mode: 'event-driven',
    events: ['MATCH_STARTED','MATCH_UPDATED','MATCH_COMPLETED','PLAYER_TRANSFERRED','MARKET_VALUE_UPDATED','STADIUM_EVENT'],
    status: 'READY_FOR_LIVE_PROVIDER',
  })
}

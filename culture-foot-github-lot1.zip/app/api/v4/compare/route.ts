import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({
    supported: ['player','club','competition','stadium'],
    metrics: ['goals','appearances','minutes','attendance','capacity','revenue','transferSpend','transferIncome'],
    note: 'Les métriques doivent conserver leur définition et leur provenance.',
  })
}

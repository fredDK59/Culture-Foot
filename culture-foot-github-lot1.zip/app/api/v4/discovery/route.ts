import { NextResponse } from 'next/server'
import { diversifyDiscovery } from '@/lib/v4/discovery'

export async function GET() {
  const candidates = [
    { entityType:'player', entityId:'kylian-mbappe', topic:'career', reason:'Vous consultez sa carrière', score:0.94, diversityKey:'career' },
    { entityType:'stadium', entityId:'parc-des-princes', topic:'stadiums', reason:'Une connexion avec le sujet actuel', score:0.87, diversityKey:'stadium' },
    { entityType:'competition', entityId:'ligue-1', topic:'history', reason:'Pour replacer le sujet dans son contexte', score:0.81, diversityKey:'history' },
  ]
  return NextResponse.json({
    principle: 'Culture Foot Propose. Le Visiteur Dispose.',
    items: diversifyDiscovery(candidates),
  })
}

import { NextResponse } from 'next/server'
import { coverageContract } from '@/lib/v19/coverage'
export async function GET(){return NextResponse.json(coverageContract)}

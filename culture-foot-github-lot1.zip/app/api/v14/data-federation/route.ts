import { NextResponse } from 'next/server'
import { dataFederation } from '@/lib/v14/data-federation'
export async function GET(){return NextResponse.json(dataFederation)}

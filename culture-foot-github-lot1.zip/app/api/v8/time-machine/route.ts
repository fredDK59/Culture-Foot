import { makeTimeContext } from '@/lib/culture-foot/time-machine'

export async function GET(request: Request) {
  const url = new URL(request.url)
  const year = Number(url.searchParams.get('year') ?? new Date().getUTCFullYear())
  const entityType = url.searchParams.get('entityType') ?? 'football'
  const entityId = url.searchParams.get('entityId') ?? 'global'
  if (!Number.isInteger(year) || year < 1800 || year > 2200) {
    return Response.json({ error: 'year must be an integer between 1800 and 2200' }, { status: 400 })
  }
  return Response.json({ version: 'v8', context: makeTimeContext({ year, entityType, entityId, confidence: 'PARTIAL' }) })
}

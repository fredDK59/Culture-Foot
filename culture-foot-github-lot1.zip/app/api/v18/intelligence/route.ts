import { NextResponse } from 'next/server'
import { intelligenceContract } from '@/lib/v18/intelligence'
export async function GET(){return NextResponse.json(intelligenceContract)}

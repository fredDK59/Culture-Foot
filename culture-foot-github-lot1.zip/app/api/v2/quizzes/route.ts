import { db } from "@/lib/db";
import { jsonSafe } from "@/lib/v2/serialize";
export async function GET() { const rows = await db.quiz.findMany({ include:{questions:{orderBy:{position:"asc"},include:{answers:{orderBy:{position:"asc"}}}}}, orderBy:{createdAt:"desc"} }); return Response.json(jsonSafe(rows)); }

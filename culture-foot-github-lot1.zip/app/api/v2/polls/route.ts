import { db } from "@/lib/db";
import { jsonSafe } from "@/lib/v2/serialize";
export async function GET() {
  const rows = await db.poll.findMany({ where: { status: "OPEN" }, include: { options: { orderBy: { position: "asc" }, include: { _count: { select: { votes: true } } } } }, orderBy: { createdAt: "desc" } });
  return Response.json(jsonSafe(rows));
}
export async function POST(req: Request) {
  const body = await req.json();
  const pollId = String(body.pollId || ""); const optionId = String(body.optionId || "");
  if (!pollId || !optionId) return Response.json({ error: "pollId et optionId sont requis" }, { status: 400 });
  const option = await db.pollOption.findFirst({ where: { id: optionId, pollId } });
  if (!option) return Response.json({ error: "Option inconnue" }, { status: 404 });
  const vote = await db.pollVote.create({ data: { pollId, optionId, voterKey: body.voterKey ? String(body.voterKey) : null } });
  return Response.json(jsonSafe(vote), { status: 201 });
}

import { db } from "@/lib/db";
import { jsonSafe } from "@/lib/v2/serialize";
export async function GET() {
  const [clubs, stadiums] = await Promise.all([
    db.club.findMany({ where: { city: { not: null } }, select: { id:true, slug:true, name:true, city:true, countryCode:true, status:true } }),
    db.stadium.findMany({ where: { city: { not: null } }, select: { id:true, slug:true, name:true, city:true, countryCode:true, capacity:true, club:{select:{name:true,slug:true}} } })
  ]);
  return Response.json(jsonSafe({ clubs, stadiums, principle: "Ville → Club → Stade → Match → Joueur" }));
}

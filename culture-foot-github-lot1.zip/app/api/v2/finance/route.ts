import { db } from "@/lib/db";
import { jsonSafe } from "@/lib/v2/serialize";
export async function GET(req: Request) {
  const url = new URL(req.url); const club = url.searchParams.get("club");
  const rows = await db.clubFinance.findMany({ where: club ? { club: { slug: club } } : undefined, include: { club:true, season:true, source:true }, orderBy: { season: { startDate: "desc" } } });
  return Response.json(jsonSafe(rows));
}

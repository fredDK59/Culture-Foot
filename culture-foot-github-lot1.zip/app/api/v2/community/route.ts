import { db } from "@/lib/db";
import { jsonSafe } from "@/lib/v2/serialize";
export async function GET() { return Response.json(jsonSafe(await db.communityIdea.findMany({ orderBy: { createdAt: "desc" } }))); }
export async function POST(req: Request) {
  const b = await req.json();
  if (!b.title || !b.description || !b.category) return Response.json({ error: "title, description et category sont requis" }, { status: 400 });
  const row = await db.communityIdea.create({ data: { title: String(b.title).slice(0,140), description: String(b.description).slice(0,1000), category: String(b.category).slice(0,60), authorLabel: b.authorLabel ? String(b.authorLabel).slice(0,80) : "Visiteur" } });
  return Response.json(jsonSafe(row), { status: 201 });
}

import { db } from "@/lib/db";
import { jsonSafe } from "@/lib/v2/serialize";
export async function GET() {
  const rows = await db.analysis.findMany({ where: { status: "PUBLISHED" }, orderBy: { publishedAt: "desc" } });
  return Response.json(jsonSafe(rows));
}

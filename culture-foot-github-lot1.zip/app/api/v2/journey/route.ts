import { db } from "@/lib/db";
import { jsonSafe } from "@/lib/v2/serialize";
export async function GET() { const row = await db.journeyCollection.findUnique({ where:{key:"demo-journey"}, include:{items:{orderBy:{createdAt:"asc"}}} }); return Response.json(jsonSafe(row)); }

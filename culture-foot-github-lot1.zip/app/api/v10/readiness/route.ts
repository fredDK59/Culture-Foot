import { readinessReport } from '@/lib/culture-foot/readiness'

export async function GET() {
  const report = readinessReport([
    { key: 'canonical-contracts', ok: true, note: 'Contrats V5+ présents.' },
    { key: 'governance-docs', ok: true, note: 'Gouvernance documentée.' },
    { key: 'health-endpoint', ok: true, note: 'Health endpoint présent.' },
    { key: 'external-database', ok: Boolean(process.env.DATABASE_URL), note: 'DATABASE_URL requis pour la production.' },
  ])
  return Response.json({ version: 'v10', ...report }, { status: report.ready ? 200 : 503 })
}

export async function GET() {
  return Response.json({
    ok: true,
    service: 'culture-foot',
    version: '10.0.0',
    architecture: 'v5-v10',
    timestamp: new Date().toISOString(),
  })
}

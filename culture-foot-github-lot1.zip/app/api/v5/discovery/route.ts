import { buildDiscovery } from '@/lib/culture-foot/discovery-policy'

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({})) as {
    intent?: string
    answer?: { id: string; type: 'player' | 'club' | 'competition' | 'season' | 'match' | 'stadium' | 'transfer' | 'analysis' | 'media' | 'national-team'; label: string }
    proposals?: Array<{ entity: { id: string; type: 'player' | 'club' | 'competition' | 'season' | 'match' | 'stadium' | 'transfer' | 'analysis' | 'media' | 'national-team'; label: string }; reason: string }>
  }
  return Response.json(buildDiscovery(body.intent ?? 'explore', body.answer ?? null, (body.proposals ?? []).map((proposal) => ({ ...proposal, optional: true }))))
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}))
  return Response.json({
    version: 'v6',
    status: 'ACCEPTED',
    idempotencyKey: body?.idempotencyKey ?? null,
    pipeline: ['COLLECTE', 'RAW', 'NORMALISATION', 'CONTRÔLE', 'VERSIONNEMENT', 'PUBLICATION'],
    note: 'V6 définit le contrat d’ingestion ; le worker réel dépend de la source connectée.',
  }, { status: 202 })
}

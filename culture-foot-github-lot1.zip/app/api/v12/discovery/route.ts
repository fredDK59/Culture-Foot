import { NextRequest, NextResponse } from 'next/server'
import { searchCatalog } from '@/lib/v11/catalog'
import { proposeDiscovery } from '@/lib/v12/discovery'
export async function GET(request: NextRequest) {
  const query = request.nextUrl.searchParams.get('q') ?? ''
  const results = searchCatalog(query)
  const answer = results[0] ?? null
  return NextResponse.json({query, answer, proposals: proposeDiscovery(answer), principle:'PROPOSE_NOT_IMPOSE'})
}

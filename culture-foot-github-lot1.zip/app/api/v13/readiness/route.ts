import { NextResponse } from 'next/server'
import { v13Readiness } from '@/lib/v13/readiness'
export async function GET() { return NextResponse.json(v13Readiness()) }

import { NextResponse } from 'next/server'
import { canonicalCatalog } from '@/lib/v11/catalog'
export async function GET() { return NextResponse.json({version:'13.0.0', count:canonicalCatalog.length, entities:canonicalCatalog}) }

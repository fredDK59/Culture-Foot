import { NextResponse } from 'next/server'
import { launchContract } from '@/lib/v20/launch'
export async function GET(){return NextResponse.json(launchContract)}

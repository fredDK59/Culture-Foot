import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({
    pipeline: ["COLLECTE", "RAW", "NORMALISATION", "CONTRÔLE", "VERSIONNEMENT", "PUBLICATION"],
    providers: [],
    status: "READY_FOR_CONNECTED_SOURCES",
    note: "V3 ne dépend d'aucun fournisseur unique.",
  })
}

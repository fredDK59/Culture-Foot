import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({
    scope: "football-geography",
    hierarchy: ["world", "continent", "country", "city", "stadium"],
    measures: ["population", "stadiumCapacity", "attendance", "clubs", "revenue", "performance"],
    methodology: "Les périmètres géographiques doivent rester explicitement définis et sourcés.",
  })
}

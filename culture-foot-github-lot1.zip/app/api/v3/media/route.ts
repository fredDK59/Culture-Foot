import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({
    kinds: ["PHOTO", "VIDEO", "AUDIO", "DOCUMENT", "ARCHIVE"],
    provenance: ["credit", "source", "capturedAt", "publishedAt"],
    rights: "Chaque média doit conserver son statut de droits et sa provenance avant publication.",
  })
}

import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({
    severities: ["INFO", "WARNING", "ERROR", "CRITICAL"],
    checks: [
      "duplicate-entities",
      "impossible-dates",
      "negative-capacity",
      "invalid-transfer-amount",
      "missing-source",
      "broken-relation",
      "time-series-gap",
    ],
  })
}

import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({
    analyses: [
      "population-vs-stadium-capacity",
      "attendance-vs-capacity",
      "revenue-vs-performance",
      "transfer-market-evolution",
      "historical-competition-growth",
    ],
    principle: "Chaque indicateur reste accompagné de sa définition, de son périmètre et de sa provenance.",
  })
}

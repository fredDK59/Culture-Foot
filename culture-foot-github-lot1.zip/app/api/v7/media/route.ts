export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}))
  return Response.json({
    version: 'v7',
    status: 'ACCEPTED',
    media: {
      kind: body?.kind ?? 'PHOTO',
      entityType: body?.entityType ?? null,
      entityId: body?.entityId ?? null,
      provenance: body?.provenance ?? null,
      rights: body?.rights ?? null,
    },
  }, { status: 202 })
}

import { NextResponse } from 'next/server'
import { publicBetaContract } from '@/lib/v17/public-beta'
export async function GET(){return NextResponse.json(publicBetaContract)}

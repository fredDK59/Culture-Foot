export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}))
  return Response.json({
    version: 'v9',
    status: 'DRAFT',
    analysis: {
      question: body?.question ?? null,
      methodology: body?.methodology ?? null,
      datasetRefs: Array.isArray(body?.datasetRefs) ? body.datasetRefs : [],
      conclusion: body?.conclusion ?? null,
      reproducible: Array.isArray(body?.datasetRefs) && body.datasetRefs.length > 0,
    },
  })
}

import { NextResponse } from 'next/server'
import { mediaNetwork } from '@/lib/v15/media-network'
export async function GET(){return NextResponse.json(mediaNetwork)}

import { NextResponse } from 'next/server'
import { observabilityContract } from '@/lib/v16/observability'
export async function GET(){return NextResponse.json(observabilityContract)}

import "dotenv/config";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../generated/prisma/client";

const connectionString = process.env.DATABASE_URL;
if (!connectionString) throw new Error("DATABASE_URL is required to seed Culture Foot.");
const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString }) });

async function main() {
  const sourceFFF = await prisma.source.upsert({
    where: { id: "source-fff" },
    update: {},
    create: {
      id: "source-fff",
      name: "Fédération Française de Football",
      type: "OFFICIAL",
      url: "https://www.fff.fr/",
    },
  });

  const sourceLigue1 = await prisma.source.upsert({
    where: { id: "source-ligue1" },
    update: { url: "https://ligue1.com/" },
    create: {
      id: "source-ligue1",
      name: "Ligue 1",
      type: "OFFICIAL",
      url: "https://ligue1.com/",
    },
  });

  const sourcePSG = await prisma.source.upsert({
    where: { id: "source-psg" },
    update: { url: "https://www.psg.fr/le-club/installations/parc-des-princes" },
    create: {
      id: "source-psg",
      name: "Paris Saint-Germain",
      type: "OFFICIAL",
      url: "https://www.psg.fr/le-club/installations/parc-des-princes",
    },
  });

  const sourceTransfermarkt = await prisma.source.upsert({
    where: { id: "source-transfermarkt" },
    update: { url: "https://www.transfermarkt.com/kylian-mbappe/transfers/spieler/342229" },
    create: {
      id: "source-transfermarkt",
      name: "Transfermarkt",
      type: "SPECIALIST",
      url: "https://www.transfermarkt.com/kylian-mbappe/transfers/spieler/342229",
    },
  });

  const sourceReal = await prisma.source.upsert({
    where: { id: "source-real-madrid" },
    update: {},
    create: {
      id: "source-real-madrid",
      name: "Real Madrid",
      type: "OFFICIAL",
      url: "https://www.realmadrid.com/",
    },
  });

  const psg = await prisma.club.upsert({
    where: { slug: "paris-saint-germain" },
    update: {},
    create: {
      slug: "paris-saint-germain",
      name: "Paris Saint-Germain",
      shortName: "PSG",
      countryCode: "FR",
      city: "Paris",
    },
  });

  const monaco = await prisma.club.upsert({
    where: { slug: "as-monaco" },
    update: {},
    create: {
      slug: "as-monaco",
      name: "AS Monaco",
      shortName: "Monaco",
      countryCode: "MC",
      city: "Monaco",
    },
  });

  const real = await prisma.club.upsert({
    where: { slug: "real-madrid" },
    update: {},
    create: {
      slug: "real-madrid",
      name: "Real Madrid",
      shortName: "Real Madrid",
      countryCode: "ES",
      city: "Madrid",
    },
  });

  const parc = await prisma.stadium.upsert({
    where: { slug: "parc-des-princes" },
    update: { name: "Parc des Princes", city: "Paris", countryCode: "FR", capacity: 48000, openedAt: new Date("1972-06-04T00:00:00Z"), clubId: psg.id },
    create: {
      slug: "parc-des-princes",
      name: "Parc des Princes",
      city: "Paris",
      countryCode: "FR",
      capacity: 48000,
      openedAt: new Date("1972-06-04T00:00:00Z"),
      clubId: psg.id,
    },
  });

  const ligue1 = await prisma.competition.upsert({
    where: { slug: "ligue-1" },
    update: {},
    create: {
      slug: "ligue-1",
      name: "Ligue 1",
      countryCode: "FR",
    },
  });

  const laliga = await prisma.competition.upsert({
    where: { slug: "laliga" },
    update: {},
    create: {
      slug: "laliga",
      name: "LaLiga",
      countryCode: "ES",
    },
  });

  const person = await prisma.person.upsert({
    where: { slug: "kylian-mbappe" },
    update: { displayName: "Kylian Mbappé" },
    create: {
      slug: "kylian-mbappe",
      displayName: "Kylian Mbappé",
      birthDate: new Date("1998-12-20T00:00:00Z"),
      status: "ACTIVE",
    },
  });

  const player = await prisma.player.upsert({
    where: { personId: person.id },
    update: {
      currentClubId: real.id,
      nationalityCode: "FR",
      position: "Attaquant",
    },
    create: {
      personId: person.id,
      currentClubId: real.id,
      nationalityCode: "FR",
      position: "Attaquant",
    },
  });

  const season2016 = await prisma.season.upsert({
    where: {
      competitionId_name: {
        competitionId: ligue1.id,
        name: "2016-2017",
      },
    },
    update: {},
    create: {
      competitionId: ligue1.id,
      name: "2016-2017",
      startDate: new Date("2016-08-01T00:00:00Z"),
      endDate: new Date("2017-06-01T00:00:00Z"),
    },
  });

  const season2017 = await prisma.season.upsert({
    where: { competitionId_name: { competitionId: ligue1.id, name: "2017-2018" } },
    update: {},
    create: { competitionId: ligue1.id, name: "2017-2018", startDate: new Date("2017-08-01T00:00:00Z"), endDate: new Date("2018-06-01T00:00:00Z") },
  });

  const season2018 = await prisma.season.upsert({
    where: { competitionId_name: { competitionId: ligue1.id, name: "2018-2019" } },
    update: {},
    create: { competitionId: ligue1.id, name: "2018-2019", startDate: new Date("2018-08-01T00:00:00Z"), endDate: new Date("2019-06-01T00:00:00Z") },
  });

  const matchSeason2018 = season2017;

  const matchPsgMonaco = await prisma.match.upsert({
    where: { id: "match-psg-monaco-2018-04-15" },
    update: {
      homeScore: 7, awayScore: 1, stadiumId: parc.id, competitionId: ligue1.id, seasonId: matchSeason2018.id,
    },
    create: {
      id: "match-psg-monaco-2018-04-15",
      seasonId: matchSeason2018.id,
      competitionId: ligue1.id,
      homeClubId: psg.id,
      awayClubId: monaco.id,
      kickoffAt: new Date("2018-04-15T19:00:00Z"),
      homeScore: 7,
      awayScore: 1,
      stadiumId: parc.id,
    },
  });

  await prisma.playerMatchAppearance.upsert({
    where: { playerId_matchId: { playerId: player.id, matchId: matchPsgMonaco.id } },
    update: { started: false, goals: 0, assists: 0 },
    create: {
      playerId: player.id,
      matchId: matchPsgMonaco.id,
      started: false,
      goals: 0,
      assists: 0,
    },
  });

  await prisma.transfer.upsert({
    where: { id: "transfer-mbappe-monaco-psg" },
    update: { transferDate: new Date("2018-07-01T00:00:00Z"), transferType: "PERMANENT", amountCents: 18000000000n, currency: "EUR", evidence: "VERIFIED", sourceId: sourceTransfermarkt.id },
    create: {
      id: "transfer-mbappe-monaco-psg", playerId: player.id, fromClubId: monaco.id, toClubId: psg.id,
      transferDate: new Date("2018-07-01T00:00:00Z"), transferType: "PERMANENT", amountCents: 18000000000n, currency: "EUR",
      evidence: "VERIFIED", sourceId: sourceTransfermarkt.id,
    },
  });

  await prisma.transfer.upsert({
    where: { id: "transfer-mbappe-psg-real-2024" },
    update: { transferDate: new Date("2024-07-01T00:00:00Z"), transferType: "FREE_TRANSFER", amountCents: null, currency: "EUR", evidence: "VERIFIED", sourceId: sourceReal.id },
    create: {
      id: "transfer-mbappe-psg-real-2024", playerId: player.id, fromClubId: psg.id, toClubId: real.id,
      transferDate: new Date("2024-07-01T00:00:00Z"), transferType: "FREE_TRANSFER", amountCents: null, currency: "EUR",
      evidence: "VERIFIED", sourceId: sourceReal.id,
    },
  });

  const marketValues = [
    { id: "mv-mbappe-2018-12", observedAt: new Date("2018-12-17T00:00:00Z"), amountCents: 20000000000n },
    { id: "mv-mbappe-2021-04", observedAt: new Date("2021-04-09T00:00:00Z"), amountCents: 16000000000n },
    { id: "mv-mbappe-2026-06", observedAt: new Date("2026-06-05T00:00:00Z"), amountCents: 18000000000n },
  ];
  for (const value of marketValues) {
    await prisma.playerMarketValue.upsert({
      where: { id: value.id },
      update: { ...value, currency: "EUR", evidence: "ESTIMATED", sourceId: sourceTransfermarkt.id },
      create: { ...value, playerId: player.id, currency: "EUR", evidence: "ESTIMATED", sourceId: sourceTransfermarkt.id },
    });
  }

  const season2025 = await prisma.season.upsert({
    where: {
      competitionId_name: {
        competitionId: laliga.id,
        name: "2025-2026",
      },
    },
    update: {},
    create: {
      competitionId: laliga.id,
      name: "2025-2026",
      startDate: new Date("2025-08-01T00:00:00Z"),
      endDate: new Date("2026-06-01T00:00:00Z"),
    },
  });

  await prisma.playerClubSpell.upsert({
    where: { id: "spell-mbappe-monaco" },
    update: {},
    create: {
      id: "spell-mbappe-monaco",
      playerId: player.id,
      clubId: monaco.id,
      startDate: new Date("2015-07-01T00:00:00Z"),
      endDate: new Date("2017-06-30T00:00:00Z"),
    },
  });

  await prisma.playerClubSpell.upsert({
    where: { id: "spell-mbappe-psg" },
    update: {},
    create: {
      id: "spell-mbappe-psg",
      playerId: player.id,
      clubId: psg.id,
      startDate: new Date("2017-07-01T00:00:00Z"),
      endDate: new Date("2024-06-30T00:00:00Z"),
    },
  });

  await prisma.playerClubSpell.upsert({
    where: { id: "spell-mbappe-real" },
    update: {},
    create: {
      id: "spell-mbappe-real",
      playerId: player.id,
      clubId: real.id,
      startDate: new Date("2024-07-01T00:00:00Z"),
    },
  });

  const seasonStats = [
    { id: "stat-mbappe-2016-17-l1", seasonId: season2016.id, clubId: monaco.id, goals: 15, evidence: "VERIFIED" as const },
    { id: "stat-mbappe-2017-18-l1", seasonId: season2017.id, clubId: psg.id, goals: 13, evidence: "VERIFIED" as const },
    { id: "stat-mbappe-2018-19-l1", seasonId: season2018.id, clubId: psg.id, goals: 33, evidence: "VERIFIED" as const },
  ];
  for (const stat of seasonStats) {
    await prisma.playerSeasonStat.upsert({
      where: { id: stat.id },
      update: { ...stat, sourceId: sourceLigue1.id },
      create: { ...stat, playerId: player.id, sourceId: sourceLigue1.id },
    });
  }

  await prisma.sourceObservation.upsert({
    where: { id: "obs-parc-psg" },
    update: {},
    create: { id: "obs-parc-psg", sourceId: sourcePSG.id, entityType: "STADIUM", entityId: parc.id, field: "residentClub", value: "Paris Saint-Germain", scope: "Current resident club", evidence: "VERIFIED" },
  });

  await prisma.sourceObservation.upsert({
    where: { id: "obs-match-psg-monaco-2018" },
    update: {},
    create: {
      id: "obs-match-psg-monaco-2018",
      sourceId: sourcePSG.id,
      entityType: "MATCH",
      entityId: matchPsgMonaco.id,
      field: "result",
      value: "Paris Saint-Germain 7-1 AS Monaco",
      scope: "Ligue 1, 15 April 2018, Parc des Princes",
      evidence: "VERIFIED",
    },
  });

  // Deliberately only store source-backed identity facts here.
  await prisma.sourceObservation.upsert({
    where: { id: "obs-mbappe-name-fff" },
    update: {},
    create: {
      id: "obs-mbappe-name-fff",
      sourceId: sourceFFF.id,
      entityType: "PLAYER",
      entityId: player.id,
      field: "displayName",
      value: "Kylian Mbappé",
      scope: "Player identity",
      evidence: "VERIFIED",
    },
  });

  await prisma.sourceObservation.upsert({
    where: { id: "obs-mbappe-real-identity" },
    update: {},
    create: {
      id: "obs-mbappe-real-identity",
      sourceId: sourceReal.id,
      entityType: "PLAYER",
      entityId: player.id,
      field: "currentClub",
      value: "Real Madrid",
      scope: "Current club",
      evidence: "VERIFIED",
    },
  });

  const relations = [
    ["PLAYER", player.id, "played_for", "CLUB", monaco.id, 1],
    ["PLAYER", player.id, "played_for", "CLUB", psg.id, 1],
    ["PLAYER", player.id, "played_for", "CLUB", real.id, 1],
    ["PLAYER", player.id, "belongs_to", "COMPETITION", ligue1.id, 0.9],
    ["PLAYER", player.id, "belongs_to", "COMPETITION", laliga.id, 0.9],
  ] as const;

  for (const [fromType, fromId, relationType, toType, toId, weight] of relations) {
    await prisma.entityRelation.create({
      data: {
        fromType,
        fromId,
        relationType,
        toType,
        toId,
        weight,
        evidence: "VERIFIED",
        sourceId: sourceFFF.id,
      },
    }).catch(() => {});
  }

  const france = await prisma.nationalTeam.upsert({
    where: { code: "FRA" },
    update: {},
    create: { name: "France", code: "FRA", federation: "FFF" },
  });

  await prisma.playerNationalTeam.upsert({
    where: { playerId_nationalTeamId: { playerId: player.id, nationalTeamId: france.id } },
    update: { startDate: new Date("2017-03-25"), evidenceStatus: "VERIFIED" },
    create: {
      playerId: player.id,
      nationalTeamId: france.id,
      startDate: new Date("2017-03-25"),
      evidenceStatus: "VERIFIED",
    },
  });

  const honours = [
    ["Coupe du Monde", "France", 2018],
    ["UEFA Nations League", "France", 2021],
    ["Euro U-19", "France U19", 2016],
    ["Ligue 1", "AS Monaco", 2017],
    ["Ligue 1", "Paris Saint-Germain", 2018],
    ["Ligue 1", "Paris Saint-Germain", 2019],
    ["Ligue 1", "Paris Saint-Germain", 2020],
    ["Ligue 1", "Paris Saint-Germain", 2022],
    ["Ligue 1", "Paris Saint-Germain", 2023],
    ["Ligue 1", "Paris Saint-Germain", 2024],
  ];

  for (const [title, team, year] of honours) {
    await prisma.honour.upsert({
      where: { id: `player-${String(year)}-${String(title).toLowerCase().replaceAll(" ", "-")}` },
      update: {},
      create: {
        id: `player-${String(year)}-${String(title).toLowerCase().replaceAll(" ", "-")}`,
        playerId: player.id,
        title: String(title),
        year: Number(year),
        team: String(team),
        evidenceStatus: "VERIFIED",
      },
    });
  }

  // Historical Ligue 1 goals are seeded from official Ligue 1 publications.
  // When appearances are not explicitly represented by the source used here,
  // we intentionally leave them NULL instead of reconstructing them.
  const ligue1MetricRows = [
    { season: "2016-2017", club: monaco, goals: 15 },
    { season: "2017-2018", club: psg, goals: 13 },
    { season: "2018-2019", club: psg, goals: 33, appearances: 29 },
    { season: "2019-2020", club: psg, goals: 18 },
    { season: "2020-2021", club: psg, goals: 27 },
    { season: "2021-2022", club: psg, goals: 28 },
    { season: "2022-2023", club: psg, goals: 29 },
    { season: "2023-2024", club: psg, goals: 27, appearances: 29 },
  ];

  const ligue1Seasons: Record<string, string> = {
    "2016-2017": season2016.id,
    "2017-2018": season2017.id,
    "2018-2019": season2018.id,
  };

  for (const year of ["2019-2020", "2020-2021", "2021-2022", "2022-2023", "2023-2024"]) {
    const [startYear, endYear] = year.split("-").map(Number);
    const season = await prisma.season.upsert({
      where: { competitionId_name: { competitionId: ligue1.id, name: year } },
      update: {},
      create: {
        competitionId: ligue1.id,
        name: year,
        startDate: new Date(`${startYear}-08-01T00:00:00Z`),
        endDate: new Date(`${endYear}-06-01T00:00:00Z`),
      },
    });
    ligue1Seasons[year] = season.id;
  }

  for (const row of ligue1MetricRows) {
    const seasonId = ligue1Seasons[row.season];
    await prisma.playerSeasonMetric.upsert({
      where: { key: `mbappe-ligue1-${row.season}` },
      update: {
        clubId: row.club.id,
        competitionId: ligue1.id,
        appearances: row.appearances ?? null,
        goals: row.goals,
        evidenceStatus: "VERIFIED",
        sourceId: sourceLigue1.id,
        sourceDate: new Date("2024-08-13T00:00:00Z"),
        definition: "Buts en Ligue 1 sur la saison ; apparitions uniquement lorsque explicitement documentées par la source.",
      },
      create: {
        key: `mbappe-ligue1-${row.season}`,
        playerId: player.id,
        seasonId,
        clubId: row.club.id,
        competitionId: ligue1.id,
        appearances: row.appearances ?? null,
        goals: row.goals,
        evidenceStatus: "VERIFIED",
        sourceId: sourceLigue1.id,
        sourceDate: new Date("2024-08-13T00:00:00Z"),
        definition: "Buts en Ligue 1 sur la saison ; apparitions uniquement lorsque explicitement documentées par la source.",
      },
    });
  }

  // France scope: a separately modelled national-team metric, not mixed with club football.
  const worldCup = await prisma.competition.upsert({
    where: { slug: "coupe-du-monde" },
    update: {},
    create: { slug: "coupe-du-monde", name: "Coupe Du Monde", countryCode: "INT" },
  });
  const worldCup2018 = await prisma.season.upsert({
    where: { competitionId_name: { competitionId: worldCup.id, name: "2018" } },
    update: {},
    create: {
      competitionId: worldCup.id,
      name: "2018",
      startDate: new Date("2018-06-14T00:00:00Z"),
      endDate: new Date("2018-07-15T00:00:00Z"),
    },
  });

  await prisma.playerSeasonMetric.upsert({
    where: { key: "mbappe-france-worldcup-2018" },
    update: {
      seasonId: worldCup2018.id,
      competitionId: worldCup.id,
      nationalTeamId: france.id,
      appearances: 7,
      goals: 4,
      evidenceStatus: "VERIFIED",
      sourceId: sourceFFF.id,
      sourceDate: null,
      definition: "Matchs et buts de Kylian Mbappé avec la France en Coupe du Monde 2018.",
    },
    create: {
      key: "mbappe-france-worldcup-2018",
      playerId: player.id,
      seasonId: worldCup2018.id,
      competitionId: worldCup.id,
      nationalTeamId: france.id,
      appearances: 7,
      goals: 4,
      evidenceStatus: "VERIFIED",
      sourceId: sourceFFF.id,
      sourceDate: null,
      definition: "Matchs et buts de Kylian Mbappé avec la France en Coupe du Monde 2018.",
    },
  });



  // V2: club performance, finance/provenance, stadium history, analyses, polls, community and quiz.
  const realStadium = await prisma.stadium.upsert({
    where: { slug: "santiago-bernabeu" },
    update: { name: "Santiago Bernabéu", city: "Madrid", countryCode: "ES", capacity: 84000, clubId: real.id },
    create: { slug: "santiago-bernabeu", name: "Santiago Bernabéu", city: "Madrid", countryCode: "ES", capacity: 84000, openedAt: new Date("1947-12-14T00:00:00Z"), clubId: real.id },
  });

  await prisma.stadiumHistory.upsert({
    where: { id: "stadium-history-parc-1972" },
    update: { name: "Parc des Princes", capacity: 48000, eventType: "INAUGURATION", description: "Ouverture du stade actuel en 1972.", evidence: "VERIFIED", sourceId: sourcePSG.id },
    create: { id: "stadium-history-parc-1972", stadiumId: parc.id, fromDate: new Date("1972-06-04T00:00:00Z"), name: "Parc des Princes", capacity: 48000, eventType: "INAUGURATION", description: "Ouverture du stade actuel en 1972.", evidence: "VERIFIED", sourceId: sourcePSG.id },
  });

  await prisma.clubSeason.upsert({
    where: { clubId_seasonId: { clubId: psg.id, seasonId: season2017.id } },
    update: { position: 1, points: 93, matchesPlayed: 38, wins: 29, draws: 6, losses: 3, goalsFor: 108, goalsAgainst: 29, evidence: "VERIFIED", sourceId: sourceLigue1.id },
    create: { clubId: psg.id, seasonId: season2017.id, position: 1, points: 93, matchesPlayed: 38, wins: 29, draws: 6, losses: 3, goalsFor: 108, goalsAgainst: 29, evidence: "VERIFIED", sourceId: sourceLigue1.id },
  });
  await prisma.clubSeason.upsert({
    where: { clubId_seasonId: { clubId: monaco.id, seasonId: season2017.id } },
    update: { position: 2, points: 80, matchesPlayed: 38, wins: 24, draws: 8, losses: 6, goalsFor: 85, goalsAgainst: 45, evidence: "VERIFIED", sourceId: sourceLigue1.id },
    create: { clubId: monaco.id, seasonId: season2017.id, position: 2, points: 80, matchesPlayed: 38, wins: 24, draws: 8, losses: 6, goalsFor: 85, goalsAgainst: 45, evidence: "VERIFIED", sourceId: sourceLigue1.id },
  });

  const analysisRows = [
    {
      slug: "mbappe-une-carriere-en-acceleration", title: "Mbappé : Une Carrière En Accélération", category: "Joueurs",
      dek: "Relier les saisons, les clubs et les compétitions pour lire une trajectoire plutôt qu'une simple liste de chiffres.",
      question: "Que raconte la progression des buts de Mbappé lorsqu'on la replace dans son parcours de clubs ?",
      methodology: "Comparer uniquement les observations actuellement référencées et conserver leur périmètre de compétition.",
      conclusion: "La trajectoire doit être lue avec le contexte de chaque saison et non comme une seule courbe continue."
    },
    {
      slug: "argent-football-performance", title: "L’Argent Fait-Il Réellement Gagner ?", category: "Économie",
      dek: "Une question à explorer en reliant dépenses, revenus, masse salariale et performances sportives.",
      question: "Dans quelles situations les ressources économiques semblent-elles associées à la performance ?",
      methodology: "Comparer des saisons homogènes, expliciter les périmètres financiers et ne pas confondre corrélation et causalité.",
      conclusion: "La relation entre argent et performance doit être étudiée par période, compétition et définition financière."
    },
    {
      slug: "stades-capacite-affluence", title: "Les Grands Stades Sont-Ils Toujours Remplis ?", category: "Stades",
      dek: "Capacité, affluence et contexte local peuvent être reliés pour dépasser le simple chiffre de places.",
      question: "La capacité d’un stade suffit-elle à expliquer son attractivité ?",
      methodology: "Comparer capacité, affluence documentée, ville, club résident et période.",
      conclusion: "Une capacité élevée est un contexte, pas une preuve d'affluence élevée."
    }
  ];
  for (const row of analysisRows) {
    await prisma.analysis.upsert({ where: { slug: row.slug }, update: row, create: row });
  }

  const poll = await prisma.poll.upsert({
    where: { slug: "club-qui-vous-donne-le-plus-envie-de-remonter-dans-le-temps" },
    update: { question: "Quel club vous donne le plus envie de remonter dans le temps ?", category: "Histoire" },
    create: { slug: "club-qui-vous-donne-le-plus-envie-de-remonter-dans-le-temps", question: "Quel club vous donne le plus envie de remonter dans le temps ?", category: "Histoire" },
  });
  const pollOptions = ["Paris Saint-Germain", "AS Monaco", "Real Madrid", "Un autre club"];
  for (let i = 0; i < pollOptions.length; i++) {
    await prisma.pollOption.upsert({
      where: { id: `poll-option-${i + 1}` },
      update: { label: pollOptions[i], position: i },
      create: { id: `poll-option-${i + 1}`, pollId: poll.id, label: pollOptions[i], position: i },
    });
  }

  const ideas = [
    ["Identifier Une Photo Historique", "Permettre à la communauté de proposer une identification avec sources.", "Archives"],
    ["Ajouter Une Compétition", "Proposer une compétition absente avec sa période historique.", "Données"],
    ["Créer Un Comparateur", "Suggérer un nouveau comparateur de joueurs, clubs ou stades.", "Produit"],
  ];
  for (const [title, description, category] of ideas) {
    const exists = await prisma.communityIdea.findFirst({ where: { title } });
    if (!exists) await prisma.communityIdea.create({ data: { title, description, category, status: "PROPOSED", authorLabel: "Communauté Culture Foot" } });
  }

  const quiz = await prisma.quiz.upsert({
    where: { slug: "culture-foot-premiers-reperes" },
    update: { title: "Culture Foot : Premiers Repères", category: "Histoire" },
    create: { slug: "culture-foot-premiers-reperes", title: "Culture Foot : Premiers Repères", description: "Quelques questions pour jouer avec les connaissances déjà présentes dans la V1.", category: "Histoire" },
  });
  const q = await prisma.quizQuestion.upsert({
    where: { id: "quiz-q-parc" },
    update: { question: "Dans quelle ville se trouve le Parc des Princes ?", position: 0, explanation: "Le Parc des Princes se trouve à Paris." },
    create: { id: "quiz-q-parc", quizId: quiz.id, question: "Dans quelle ville se trouve le Parc des Princes ?", position: 0, explanation: "Le Parc des Princes se trouve à Paris." },
  });
  const answers = ["Paris", "Madrid", "Monaco", "Lyon"];
  for (let i = 0; i < answers.length; i++) {
    await prisma.quizAnswer.upsert({ where: { id: `quiz-a-parc-${i}` }, update: { label: answers[i], correct: i === 0, position: i }, create: { id: `quiz-a-parc-${i}`, questionId: q.id, label: answers[i], correct: i === 0, position: i } });
  }

  const journey = await prisma.journeyCollection.upsert({
    where: { key: "demo-journey" }, update: { title: "Mon Atlas Du Football" },
    create: { key: "demo-journey", title: "Mon Atlas Du Football", description: "Une collection locale de découvertes que le visiteur peut compléter." },
  });
  const journeyItems = [
    ["player", player.id, "Kylian Mbappé", "Point de départ"],
    ["club", psg.id, "Paris Saint-Germain", "Un club relié au joueur"],
    ["stadium", parc.id, "Parc des Princes", "Un stade relié au club"],
  ];
  for (const [entityType, entityId, label, note] of journeyItems) {
    const exists = await prisma.journeyItem.findFirst({ where: { collectionId: journey.id, entityType, entityId } });
    if (!exists) await prisma.journeyItem.create({ data: { collectionId: journey.id, entityType, entityId, label, note } });
  }

  console.log("Culture Foot seed OK:", {
    player: player.id,
    clubs: [monaco.id, psg.id, real.id],
    seasons: [season2016.id, season2017.id, season2018.id, season2025.id],
    stadium: parc.id,
  });
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

 'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getEntityRoute } from '@/lib/entity-routes';

type Node = {
  id: string;
  type: string;
  label: string;
  relationTypes: string[];
};

type GraphPayload = {
  center: { type: string; id: string };
  nodes: Node[];
  relations: Array<{
    from: { type: string; id: string };
    to: { type: string; id: string };
    type: string;
  }>;
};

export default function CultureFootKnowledgeGraph({
  type,
  id,
}: {
  type: string;
  id: string;
}) {
  const [graph, setGraph] = useState<GraphPayload | null>(null);
  const [selected, setSelected] = useState<Node | null>(null);

  useEffect(() => {
    fetch(`/api/v1/entities/${type}/${encodeURIComponent(id)}/graph`)
      .then((r) => r.json())
      .then(setGraph)
      .catch(() => setGraph(null));
  }, [type, id]);

  if (!graph) {
    return (
      <section className="rounded-3xl border border-sky-400/15 bg-slate-950/50 p-6 text-sky-200/50">
        Graphe En Cours De Chargement…
      </section>
    );
  }

  const neighbors = graph.nodes.filter(
    (node) => !(node.type === graph.center.type && node.id === graph.center.id)
  );

  return (
    <section className="rounded-[2rem] border border-sky-400/20 bg-[#07111f]/90 p-5 md:p-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.22em] text-sky-400/75">
            Graphe Culture Foot
          </p>
          <h2 className="mt-2 text-2xl font-black text-white">
            Tout Ce Qui Entoure Ce Sujet
          </h2>
        </div>
        <span className="rounded-full border border-sky-400/15 px-3 py-1 text-xs text-sky-200/60">
          {neighbors.length} connexions
        </span>
      </div>

      <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {neighbors.map((node) => {
          const route = getEntityRoute(node.type, node.id);

          return (
            <div
              key={`${node.type}:${node.id}`}
              className="rounded-2xl border border-sky-400/10 bg-slate-950/55 p-4 transition hover:-translate-y-0.5 hover:border-sky-400/30"
            >
              <button
                type="button"
                onClick={() => setSelected(node)}
                className="w-full text-left"
              >
                <span className="text-[10px] font-black uppercase tracking-wider text-sky-400">
                  {node.type}
                </span>
                <h3 className="mt-1 font-extrabold text-white">{node.label}</h3>
                <p className="mt-2 text-xs text-sky-200/45">
                  {node.relationTypes.join(' · ')}
                </p>
              </button>

              <Link
                href={route.href}
                className="mt-4 inline-flex min-h-11 items-center rounded-xl border border-sky-400/15 px-3 text-xs font-black uppercase tracking-wide text-sky-300 transition hover:border-sky-300/40 hover:text-white"
              >
                {route.label} →
              </Link>
            </div>
          );
        })}
      </div>

      {selected && (
        <div className="mt-5 rounded-2xl border border-emerald-400/15 bg-emerald-400/5 p-4">
          <p className="text-xs font-black uppercase tracking-wider text-emerald-300">
            Porte De Découverte
          </p>
          <p className="mt-1 font-bold text-white">{selected.label}</p>
          <p className="mt-1 text-sm text-sky-100/55">
            Cette connexion est une proposition. Vous choisissez si vous voulez l'explorer.
          </p>
        </div>
      )}
    </section>
  );
}

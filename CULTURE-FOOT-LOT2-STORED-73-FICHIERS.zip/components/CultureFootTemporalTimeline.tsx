 'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getEntityRoute } from '@/lib/entity-routes';

type Event = {
  date: string;
  kind: string;
  label: string;
  hrefType: string;
  hrefId: string;
};

export default function CultureFootTemporalTimeline({
  type,
  id,
}: {
  type: string;
  id: string;
}) {
  const [events, setEvents] = useState<Event[]>([]);

  useEffect(() => {
    fetch(`/api/v1/entities/${type}/${encodeURIComponent(id)}/timeline`)
      .then((r) => r.json())
      .then((data) => setEvents(data.events ?? []))
      .catch(() => setEvents([]));
  }, [type, id]);

  if (!events.length) return null;

  return (
    <section className="mt-8 rounded-[2rem] border border-indigo-400/20 bg-[#090b1d]/90 p-5 md:p-8">
      <p className="text-xs font-black uppercase tracking-[0.22em] text-indigo-300/80">
        Machine Temporelle
      </p>
      <h2 className="mt-2 text-2xl font-black text-white">
        Son Parcours Dans Le Temps
      </h2>
      <p className="mt-2 max-w-2xl text-sm text-sky-100/50">
        Chaque étape ouvre une nouvelle porte. Vous choisissez celle que vous voulez explorer.
      </p>

      <div className="mt-7 overflow-x-auto pb-3">
        <div className="flex min-w-max items-stretch gap-3">
          {events.map((event) => {
            const route = getEntityRoute(event.hrefType, event.hrefId);

            return (
              <div
                key={`${event.kind}:${event.date}:${event.hrefId}`}
                className="w-52 rounded-2xl border border-indigo-400/15 bg-slate-950/60 p-4"
              >
                <span className="text-xs font-black text-indigo-300">
                  {event.date}
                </span>
                <p className="mt-3 text-[10px] font-black uppercase tracking-wider text-sky-300/55">
                  {event.kind}
                </p>
                <p className="mt-1 font-bold text-white">{event.label}</p>
                <Link
                  href={route.href}
                  className="mt-4 inline-flex min-h-11 items-center text-xs font-black uppercase tracking-wide text-sky-300 hover:text-white"
                >
                  Explorer →
                </Link>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

 'use client';

import { useEffect, useState } from 'react';

type Match = {
  id: string;
  date: string;
  home: string | null;
  away: string | null;
  stadium: string | null;
  competition: string | null;
};

type Context = {
  request: { year: number | null; season: string | null };
  seasons: Array<{ id: string; label: string; competition: string | null }>;
  matches: Match[];
  transfers: Array<{
    id: string;
    date: string;
    player: string | null;
    from: string | null;
    to: string | null;
  }>;
};

const presets = [
  { label: '2018', year: '2018' },
  { label: '1998', year: '1998' },
  { label: '1982', year: '1982' },
  { label: '1966', year: '1966' },
];

export default function CultureFootTimeMachine() {
  const [year, setYear] = useState('2018');
  const [context, setContext] = useState<Context | null>(null);

  async function load(value: string) {
    setYear(value);
    const response = await fetch(`/api/v1/time-machine?year=${encodeURIComponent(value)}`);
    if (!response.ok) return;
    setContext(await response.json());
  }

  useEffect(() => {
    load('2018');
  }, []);

  return (
    <section className="rounded-[2rem] border border-indigo-400/20 bg-[#090b1d]/95 p-5 md:p-8">
      <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.24em] text-indigo-300">
            Un Saut Dans Le Temps Footballistique
          </p>
          <h2 className="mt-2 text-3xl font-black text-white">
            La Machine Temporelle
          </h2>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-sky-100/50">
            Choisissez une époque. Culture Foot reconstruit le contexte disponible
            autour de cette période.
          </p>
        </div>

        <label className="flex min-h-11 items-center gap-2 rounded-xl border border-indigo-400/20 bg-slate-950/60 px-3">
          <span className="text-xs font-black uppercase text-indigo-300/70">Année</span>
          <input
            value={year}
            onChange={(event) => setYear(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Enter') load(year);
            }}
            inputMode="numeric"
            className="w-20 bg-transparent text-right font-black text-white outline-none"
            aria-label="Année à explorer"
          />
        </label>
      </div>

      <div className="mt-5 flex flex-wrap gap-2">
        {presets.map((preset) => (
          <button
            key={preset.year}
            type="button"
            onClick={() => load(preset.year)}
            className="min-h-11 rounded-xl border border-sky-400/15 px-4 text-xs font-black uppercase tracking-wide text-sky-300 hover:border-sky-400/40 hover:text-white"
          >
            {preset.label}
          </button>
        ))}
        <button
          type="button"
          onClick={() => load(year)}
          className="min-h-11 rounded-xl bg-indigo-400/15 px-4 text-xs font-black uppercase tracking-wide text-indigo-200 hover:bg-indigo-400/25"
        >
          Explorer →
        </button>
      </div>

      {context && (
        <div className="mt-7 grid gap-4 md:grid-cols-3">
          <div className="rounded-2xl border border-sky-400/10 bg-slate-950/50 p-5">
            <p className="text-xs font-black uppercase text-sky-300/60">Compétitions</p>
            <p className="mt-2 text-3xl font-black text-white">{context.seasons.length}</p>
            <p className="mt-1 text-sm text-sky-100/40">contextes disponibles</p>
          </div>
          <div className="rounded-2xl border border-red-400/10 bg-slate-950/50 p-5">
            <p className="text-xs font-black uppercase text-red-300/60">Matchs</p>
            <p className="mt-2 text-3xl font-black text-white">{context.matches.length}</p>
            <p className="mt-1 text-sm text-sky-100/40">événements disponibles</p>
          </div>
          <div className="rounded-2xl border border-orange-400/10 bg-slate-950/50 p-5">
            <p className="text-xs font-black uppercase text-orange-300/60">Transferts</p>
            <p className="mt-2 text-3xl font-black text-white">{context.transfers.length}</p>
            <p className="mt-1 text-sm text-sky-100/40">mouvements disponibles</p>
          </div>
        </div>
      )}

      {context?.matches.length ? (
        <div className="mt-7">
          <p className="text-xs font-black uppercase tracking-[0.18em] text-sky-300/60">
            Quelques Portes De L’Époque
          </p>
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            {context.matches.slice(0, 6).map((match) => (
              <div
                key={match.id}
                className="rounded-2xl border border-sky-400/10 bg-slate-950/55 p-4"
              >
                <p className="text-xs font-black text-indigo-300">{match.date ? match.date.slice(0, 10) : 'Date Inconnue'}</p>
                <p className="mt-2 font-bold text-white">
                  {match.home ?? 'Équipe'} — {match.away ?? 'Équipe'}
                </p>
                <p className="mt-1 text-xs text-sky-100/40">
                  {match.competition ?? 'Compétition'} · {match.stadium ?? 'Stade Inconnu'}
                </p>
              </div>
            ))}
          </div>
        </div>
      ) : null}
    </section>
  );
}

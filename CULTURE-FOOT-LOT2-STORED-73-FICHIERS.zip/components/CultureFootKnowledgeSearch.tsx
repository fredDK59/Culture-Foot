'use client';

import { useState } from 'react';

type Result = {
  type: string;
  name: string;
  slug?: string;
  description?: string;
  doors?: string[];
};

const labels: Record<string, string> = {
  PLAYER: 'Joueur',
  CLUB: 'Club',
  COMPETITION: 'Compétition',
  STADIUM: 'Stade',
};

export default function CultureFootKnowledgeSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Result[]>([]);
  const [message, setMessage] = useState('');

  async function runSearch() {
    if (!query.trim()) return;

    setMessage('Exploration…');

    try {
      const response = await fetch(`/api/v1/search?q=${encodeURIComponent(query)}`);
      const data = await response.json();
      setResults(data.results ?? []);

      if (data.intents?.length) {
        const intent = data.intents[0];
        setMessage(
          `Intention détectée : ${intent.leftQuery} ↔ ${intent.rightQuery}. Vous choisissez la suite.`
        );
      } else if (data.results?.length) {
        setMessage(`${data.results.length} porte(s) trouvée(s).`);
      } else {
        setMessage('Aucune porte trouvée pour cette recherche.');
      }
    } catch {
      setMessage('La recherche est momentanément indisponible.');
    }
  }

  return (
    <section className="rounded-[2rem] border border-sky-400/20 bg-[#07111f]/90 p-5 md:p-8">
      <p className="text-xs font-black uppercase tracking-[0.25em] text-sky-400/80">
        Culture Foot
      </p>
      <h1 className="mt-2 text-3xl font-black text-white md:text-4xl">
        Entrez Par Une Question. Ressortez Avec Des Possibilités.
      </h1>
      <p className="mt-3 max-w-2xl text-sm leading-6 text-sky-100/55">
        Joueurs, clubs, stades, compétitions : une recherche peut ouvrir plusieurs
        chemins. Aucun n'est imposé.
      </p>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') runSearch();
          }}
          placeholder="PSG, Mbappé, Parc des Princes, Ligue 1…"
          className="min-h-12 flex-1 rounded-2xl border border-sky-400/20 bg-slate-950 px-4 text-white outline-none placeholder:text-sky-100/25"
          aria-label="Recherche football"
        />
        <button
          type="button"
          onClick={runSearch}
          className="min-h-12 rounded-2xl bg-sky-400 px-6 font-black text-slate-950 hover:bg-sky-300"
        >
          Explorer
        </button>
      </div>

      <p className="mt-4 text-sm text-sky-200/55" aria-live="polite">
        {message}
      </p>

      <div className="mt-7 grid gap-4 md:grid-cols-2">
        {results.map((result) => (
          <article
            key={`${result.type}-${result.name}`}
            className="rounded-2xl border border-sky-400/10 bg-slate-950/55 p-5"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-sky-400">
                  {labels[result.type] ?? result.type}
                </span>
                <h2 className="mt-1 text-xl font-black text-white">{result.name}</h2>
                {result.description && (
                  <p className="mt-1 text-xs text-sky-100/45">{result.description}</p>
                )}
              </div>
              <span className="rounded-full border border-sky-400/15 px-2 py-1 text-[10px] font-bold text-sky-200/60">
                {result.doors?.length ?? 0} portes
              </span>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {(result.doors ?? []).map((door) => (
                <button
                  key={door}
                  type="button"
                  className="rounded-full border border-sky-400/10 bg-sky-400/5 px-3 py-1.5 text-xs font-semibold text-sky-200 hover:border-sky-400/30 hover:bg-sky-400/10"
                >
                  {door}
                </button>
              ))}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

'use client';

import { useState } from 'react';

type Props = { type: string; id: string; label: string };

type ContextResult = {
  year: number;
  clubs: { id: string; name: string; startDate: string | null; endDate: string | null }[];
  metrics: { season: string; competition: string | null; club: string | null; nationalTeam: string | null; appearances: number | null; goals: number | null; assists: number | null; minutes: number | null; evidenceStatus: string }[];
  honours: { title: string; team: string | null; year: number; evidenceStatus: string }[];
  transfers: { date: string | null; type: string; from: string | null; to: string | null; amountCents: number | null; currency: string | null; evidenceStatus: string }[];
  matches: { id: string; date: string | null; home: string; away: string; score: string; stadium: string | null; competition: string | null; season: string | null }[];
  stadiums: { id: string; name: string; city: string | null; capacity: number | null; club: string | null }[];
  limitations: string[];
};

export default function CultureFootEraContext({ type, id, label }: Props) {
  const [year, setYear] = useState('2018');
  const [result, setResult] = useState<ContextResult | null>(null);
  const [loading, setLoading] = useState(false);

  async function explore() {
    const parsed = Number(year);
    if (!Number.isInteger(parsed) || parsed < 1800 || parsed > 2200) return;
    setLoading(true);
    try {
      const response = await fetch(`/api/v1/time-machine/${type}/${encodeURIComponent(id)}/context?year=${parsed}`);
      setResult(response.ok ? await response.json() : null);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="cf-section" id="era-context">
      <div className="cf-card cf-era-context">
        <div className="cf-era-head">
          <div>
            <div className="cf-label">Contexte D’Époque</div>
            <h2>{label} Dans Son Époque</h2>
            <p className="cf-muted">Un instantané documentaire : clubs, données, matchs, transferts, palmarès et lieux disponibles pour l’année choisie.</p>
          </div>
          <div className="cf-era-controls">
            <input value={year} onChange={(e) => setYear(e.target.value)} inputMode="numeric" aria-label="Année" />
            <button type="button" onClick={explore} disabled={loading}>{loading ? 'Voyage…' : 'Explorer →'}</button>
          </div>
        </div>

        {result && (
          <div className="cf-era-grid">
            <article><div className="cf-label">Clubs</div><strong>{result.clubs.length}</strong><p>{result.clubs.map((c) => c.name).join(' · ') || 'Aucun club documenté'}</p></article>
            <article><div className="cf-label">Données</div><strong>{result.metrics.length}</strong><p>{result.metrics.map((m) => `${m.goals ?? '—'} buts · ${m.season}`).join(' · ') || 'Aucune donnée statistique'}</p></article>
            <article><div className="cf-label">Matchs Référencés</div><strong>{result.matches.length}</strong><p>{result.matches.slice(0, 3).map((m) => `${m.home} ${m.score} ${m.away}`).join(' · ') || 'Aucun match documenté'}</p></article>
            <article><div className="cf-label">Palmarès</div><strong>{result.honours.length}</strong><p>{result.honours.map((h) => h.title).join(' · ') || 'Aucun titre documenté cette année'}</p></article>
            <article><div className="cf-label">Transferts</div><strong>{result.transfers.length}</strong><p>{result.transfers.map((t) => `${t.from ?? '—'} → ${t.to ?? '—'}`).join(' · ') || 'Aucun transfert documenté'}</p></article>
            <article><div className="cf-label">Stades</div><strong>{result.stadiums.length}</strong><p>{result.stadiums.map((s) => s.name).join(' · ') || 'Aucun stade relié'}</p></article>
          </div>
        )}

        {result && <div className="cf-era-limitations"><div className="cf-label">Lecture Des Données</div><ul>{result.limitations.map((item) => <li key={item}>{item}</li>)}</ul></div>}
      </div>
    </section>
  );
}

 'use client';

import Link from 'next/link';
import { getEntityRoute } from '@/lib/entity-routes';

type Suggestion = {
  type: string;
  id: string;
  relationType: string;
  reason: string;
};

export default function CultureFootDiscoveryDoors({
  suggestions,
}: {
  suggestions: Suggestion[];
}) {
  if (!suggestions.length) return null;

  return (
    <section className="mt-8">
      <p className="text-xs font-black uppercase tracking-[0.22em] text-sky-400/70">
        Si Vous Voulez Continuer
      </p>
      <h2 className="mt-2 text-2xl font-black text-white">
        Ces Portes Pourraient Vous Intéresser
      </h2>

      <div className="mt-5 flex flex-wrap gap-3">
        {suggestions.slice(0, 8).map((item) => {
          const route = getEntityRoute(item.type, item.id);

          return (
            <Link
              key={`${item.type}:${item.id}`}
              href={route.href}
              className="group rounded-2xl border border-sky-400/15 bg-[#07111f]/80 px-4 py-3 transition hover:border-sky-400/35 hover:bg-sky-400/5"
            >
              <span className="block text-[10px] font-black uppercase tracking-wider text-sky-400/70">
                {item.type} · {item.relationType}
              </span>
              <span className="mt-1 block font-bold text-white group-hover:text-sky-200">
                {item.id}
              </span>
              <span className="mt-1 block text-xs text-sky-100/40">
                {item.reason}
              </span>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

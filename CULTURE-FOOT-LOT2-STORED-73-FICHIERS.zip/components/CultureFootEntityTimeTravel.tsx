 'use client';

import { useState } from 'react';

type Props = {
  type: string;
  id: string;
  label: string;
};

type Result = {
  year: number;
  center: { type: string; id: string; label: string };
  clubs: Array<{
    id: string;
    name: string;
    startDate: string | null;
    endDate: string | null;
  }>;
  metrics: Array<{
    season: string;
    competition: string | null;
    club: string | null;
    appearances: number | null;
    goals: number | null;
    assists: number | null;
    minutes: number | null;
    evidenceStatus: string;
  }>;
};

export default function CultureFootEntityTimeTravel({
  type,
  id,
  label,
}: Props) {
  const [year, setYear] = useState('2018');
  const [result, setResult] = useState<Result | null>(null);
  const [loading, setLoading] = useState(false);

  async function explore() {
    const parsed = Number(year);
    if (!Number.isInteger(parsed) || parsed < 1800 || parsed > 2200) return;

    setLoading(true);
    try {
      const response = await fetch(
        `/api/v1/time-machine/${type}/${encodeURIComponent(id)}?year=${parsed}`
      );
      if (response.ok) setResult(await response.json());
      else setResult(null);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="rounded-[2rem] border border-indigo-400/20 bg-[#090b1d]/95 p-5 md:p-8">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.24em] text-indigo-300">
            Voyage Dans Le Temps
          </p>
          <h2 className="mt-2 text-3xl font-black text-white">
            {label} — Une Autre Époque
          </h2>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-sky-100/50">
            Changez d’année pour replacer ce sujet dans son contexte footballistique.
          </p>
        </div>

        <div className="flex gap-2">
          <input
            value={year}
            onChange={(e) => setYear(e.target.value)}
            inputMode="numeric"
            aria-label="Année"
            className="min-h-11 w-24 rounded-xl border border-indigo-400/20 bg-slate-950 px-3 text-center font-black text-white outline-none focus:border-indigo-300"
          />
          <button
            type="button"
            onClick={explore}
            disabled={loading}
            className="min-h-11 rounded-xl bg-indigo-400/15 px-5 text-xs font-black uppercase tracking-wide text-indigo-200 hover:bg-indigo-400/25 disabled:opacity-50"
          >
            {loading ? 'Voyage…' : 'Explorer →'}
          </button>
        </div>
      </div>

      {result && (
        <div className="mt-7 space-y-5">
          <div className="grid gap-3 md:grid-cols-2">
            <div className="rounded-2xl border border-sky-400/10 bg-slate-950/55 p-5">
              <p className="text-xs font-black uppercase text-sky-300/60">
                Club(s) Dans La Période
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                {result.clubs.length ? (
                  result.clubs.map((club) => (
                    <span
                      key={club.id}
                      className="rounded-full border border-sky-400/15 px-3 py-2 text-sm font-bold text-white"
                    >
                      {club.name}
                    </span>
                  ))
                ) : (
                  <span className="text-sm text-sky-100/40">
                    Aucune période de club disponible.
                  </span>
                )}
              </div>
            </div>

            <div className="rounded-2xl border border-emerald-400/10 bg-slate-950/55 p-5">
              <p className="text-xs font-black uppercase text-emerald-300/60">
                Données Disponibles
              </p>
              <p className="mt-2 text-3xl font-black text-white">
                {result.metrics.length}
              </p>
              <p className="text-sm text-sky-100/40">
                lignes statistiques documentées pour cette période
              </p>
            </div>
          </div>

          <div className="rounded-2xl border border-indigo-400/10 bg-slate-950/55 p-5">
            <p className="text-xs font-black uppercase tracking-wider text-indigo-300/70">
              Saison(s) Retrouvée(s)
            </p>

            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {result.metrics.map((metric, index) => (
                <div
                  key={`${metric.season}:${metric.competition}:${index}`}
                  className="rounded-xl border border-sky-400/10 bg-[#07111f] p-4"
                >
                  <p className="font-black text-white">{metric.season}</p>
                  <p className="mt-1 text-xs text-sky-100/45">
                    {metric.competition ?? 'Compétition inconnue'} · {metric.club ?? 'Club inconnu'}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-x-4 gap-y-2 text-xs text-sky-100/65">
                    <span>Buts : <b className="text-white">{metric.goals ?? '—'}</b></span>
                    <span>App. : <b className="text-white">{metric.appearances ?? '—'}</b></span>
                    <span>Passes : <b className="text-white">{metric.assists ?? '—'}</b></span>
                    <span>Minutes : <b className="text-white">{metric.minutes ?? '—'}</b></span>
                  </div>
                  <p className="mt-3 text-[10px] font-black uppercase text-sky-300/40">
                    {metric.evidenceStatus}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

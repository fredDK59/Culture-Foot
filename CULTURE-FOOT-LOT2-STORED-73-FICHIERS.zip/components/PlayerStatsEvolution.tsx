"use client";

import { useMemo, useState } from "react";

type Metric = {
  id: string;
  key: string;
  season: { id: string; name: string; startDate: string | null };
  club: { id: string; name: string } | null;
  competition: { id: string; name: string; slug: string } | null;
  nationalTeam: { id: string; name: string; code: string | null } | null;
  appearances: number | null;
  goals: number | null;
  assists: number | null;
  minutes: number | null;
  evidenceStatus: string;
  definition: string | null;
};

type Scope = "ligue1" | "all" | "france";
type MetricKey = "goals" | "appearances" | "assists" | "minutes";

const scopeLabels: Record<Scope, string> = {
  ligue1: "Ligue 1",
  all: "Toutes Compétitions",
  france: "France",
};

const metricLabels: Record<MetricKey, string> = {
  goals: "Buts",
  appearances: "Apparitions",
  assists: "Passes Décisives",
  minutes: "Minutes",
};

function niceValue(value: number | null) {
  return value === null ? "—" : new Intl.NumberFormat("fr-FR").format(value);
}

export default function PlayerStatsEvolution({ metrics }: { metrics: Metric[] }) {
  const [scope, setScope] = useState<Scope>("ligue1");
  const [metric, setMetric] = useState<MetricKey>("goals");
  const [selectedSeason, setSelectedSeason] = useState<string | null>(null);

  const rows = useMemo(() => {
    const filtered = metrics.filter((item) => {
      if (scope === "ligue1") return item.competition?.slug === "ligue-1";
      if (scope === "france") return item.nationalTeam?.code === "FRA";
      return true;
    });

    const bySeason = new Map<string, Metric>();
    for (const item of filtered) {
      const previous = bySeason.get(item.season.name);
      if (!previous) {
        bySeason.set(item.season.name, { ...item });
        continue;
      }
      const key = metric;
      const currentValue = item[key] ?? 0;
      const previousValue = previous[key] ?? 0;
      bySeason.set(item.season.name, { ...previous, [key]: previousValue + currentValue });
    }

    return [...bySeason.values()].sort((a, b) => (a.season.startDate ?? "").localeCompare(b.season.startDate ?? ""));
  }, [metrics, scope, metric]);

  const values = rows.map((row) => row[metric] ?? 0);
  const max = Math.max(1, ...values);
  const width = 920;
  const height = 300;
  const padX = 46;
  const padTop = 24;
  const padBottom = 48;
  const chartW = width - padX * 2;
  const chartH = height - padTop - padBottom;
  const points = rows.map((row, index) => {
    const x = rows.length <= 1 ? width / 2 : padX + (index / (rows.length - 1)) * chartW;
    const value = row[metric] ?? 0;
    const y = padTop + chartH - (value / max) * chartH;
    return { row, x, y, value };
  });
  const line = points.map((point) => `${point.x},${point.y}`).join(" ");
  const area = points.length ? `${padX},${padTop + chartH} ${line} ${width - padX},${padTop + chartH}` : "";
  const selected = rows.find((row) => row.season.name === selectedSeason) ?? rows.at(-1) ?? null;

  return (
    <section className="stats-evolution" aria-labelledby="stats-evolution-title">
      <div className="stats-evolution-head">
        <div>
          <div className="cf-label">Données Interconnectées</div>
          <h2 id="stats-evolution-title">Évolution Statistique</h2>
          <p className="cf-muted">Changez Le Périmètre Sans Quitter La Page.</p>
        </div>
        <div className="stats-controls" role="group" aria-label="Périmètre Statistique">
          {(Object.keys(scopeLabels) as Scope[]).map((item) => (
            <button key={item} type="button" className={scope === item ? "is-active" : ""} onClick={() => { setScope(item); setSelectedSeason(null); }}>
              {scopeLabels[item]}
            </button>
          ))}
        </div>
      </div>

      <div className="stats-metric-tabs" role="group" aria-label="Indicateur">
        {(Object.keys(metricLabels) as MetricKey[]).map((item) => (
          <button key={item} type="button" className={metric === item ? "is-active" : ""} onClick={() => setMetric(item)}>
            {metricLabels[item]}
          </button>
        ))}
      </div>

      <div className="stats-chart-card">
        {rows.length ? (
          <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label={`${metricLabels[metric]} de ${scopeLabels[scope]} par saison`} className="stats-chart">
            <defs>
              <linearGradient id="cfStatsFill" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="rgba(54,190,120,.38)" />
                <stop offset="100%" stopColor="rgba(54,190,120,0)" />
              </linearGradient>
            </defs>
            <line x1={padX} y1={padTop + chartH} x2={width - padX} y2={padTop + chartH} className="stats-axis" />
            {area && <polygon points={area} fill="url(#cfStatsFill)" />}
            {line && <polyline points={line} className="stats-line" fill="none" />}
            {points.map(({ row, x, y, value }) => (
              <g key={row.season.name}>
                <line x1={x} y1={y} x2={x} y2={padTop + chartH} className="stats-guide" />
                <circle cx={x} cy={y} r={selected?.season.name === row.season.name ? 7 : 5} className={selected?.season.name === row.season.name ? "stats-dot selected" : "stats-dot"} />
                <text x={x} y={height - 18} textAnchor="middle" className="stats-season">{row.season.name.slice(0, 4)}</text>
                <text x={x} y={y - 12} textAnchor="middle" className="stats-value">{niceValue(value)}</text>
                <title>{row.season.name} · {niceValue(value)} {metricLabels[metric].toLowerCase()}</title>
              </g>
            ))}
          </svg>
        ) : (
          <div className="stats-empty">Aucune Donnée Disponible Pour Ce Périmètre.</div>
        )}
      </div>

      {selected && (
        <button type="button" className="stats-detail" onClick={() => setSelectedSeason(selectedSeason === selected.season.name ? null : selected.season.name)} aria-label={`Afficher les détails de ${selected.season.name}`}>
          <span className="stats-detail-season">{selected.season.name}</span>
          <span className="stats-detail-value">{niceValue(selected[metric])}</span>
          <span className="stats-detail-context">{selected.nationalTeam?.name ?? selected.club?.name ?? selected.competition?.name ?? "Périmètre Inconnu"}</span>
          <span className="stats-detail-proof">Donnée {selected.evidenceStatus.toLowerCase()} · Source Associée</span>
        </button>
      )}
    </section>
  );
}

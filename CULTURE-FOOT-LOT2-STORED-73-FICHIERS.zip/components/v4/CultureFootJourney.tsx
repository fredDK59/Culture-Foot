'use client'
import { useState } from 'react'

type Item = { id:string; label:string; type:string }

export function CultureFootJourney() {
  const [items, setItems] = useState<Item[]>([])
  const [label, setLabel] = useState('')
  function add() {
    const value = label.trim()
    if (!value) return
    setItems(x => [...x, { id: crypto.randomUUID(), label:value, type:'discovery' }])
    setLabel('')
  }
  return (
    <section className="rounded-3xl border border-blue-500/20 bg-slate-950/80 p-6">
      <p className="text-xs uppercase tracking-[0.25em] text-blue-300">Mon Parcours</p>
      <h2 className="mt-2 text-2xl font-semibold text-white">Mon Carnet De Découvertes</h2>
      <div className="mt-5 flex gap-2">
        <input value={label} onChange={e=>setLabel(e.target.value)} placeholder="Ajouter une découverte…" className="min-w-0 flex-1 rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 text-white" />
        <button type="button" onClick={add} className="rounded-xl bg-blue-500 px-4 py-3 font-semibold text-white">Ajouter</button>
      </div>
      <ul className="mt-4 space-y-2">{items.map(x=><li key={x.id} className="rounded-xl border border-slate-800 p-3 text-slate-300">{x.label}</li>)}</ul>
      <p className="mt-4 text-xs text-slate-500">Votre parcours vous appartient.</p>
    </section>
  )
}

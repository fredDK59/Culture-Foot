import { CultureFootDiscoveryEngine } from './CultureFootDiscoveryEngine'
import { CultureFootJourney } from './CultureFootJourney'
import { CultureFootSemanticSearch } from './CultureFootSemanticSearch'

export function CultureFootV4Hub() {
  return (
    <main className="mx-auto max-w-6xl space-y-6 px-4 py-10">
      <header>
        <p className="text-sm font-semibold tracking-[0.25em] text-blue-300">CULTURE FOOT V4</p>
        <h1 className="mt-3 text-4xl font-bold text-white">Le Football Vous Propose Des Portes</h1>
        <p className="mt-3 max-w-3xl text-slate-400">Recherche sémantique, découvertes, comparaisons et parcours personnel — sans transformer votre curiosité en parcours imposé.</p>
      </header>
      <CultureFootSemanticSearch />
      <CultureFootDiscoveryEngine />
      <CultureFootJourney />
    </main>
  )
}

'use client'
import { useState } from 'react'

export function CultureFootSemanticSearch() {
  const [q, setQ] = useState('')
  const [intent, setIntent] = useState<any>(null)
  async function submit(e:React.FormEvent) {
    e.preventDefault()
    const r = await fetch(`/api/v4/search?q=${encodeURIComponent(q)}`)
    setIntent(await r.json())
  }
  return (
    <section className="rounded-3xl border border-emerald-500/20 bg-slate-950/80 p-6">
      <p className="text-xs uppercase tracking-[0.25em] text-emerald-300">Recherche</p>
      <h2 className="mt-2 text-2xl font-semibold text-white">Comprendre La Question</h2>
      <form onSubmit={submit} className="mt-5 flex gap-2">
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Ex. clubs français ayant dépensé plus de 50 M€…" className="min-w-0 flex-1 rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 text-white" />
        <button className="rounded-xl bg-emerald-500 px-4 py-3 font-semibold text-slate-950">Chercher</button>
      </form>
      {intent && <pre className="mt-4 overflow-auto rounded-xl bg-black/30 p-4 text-xs text-slate-300">{JSON.stringify(intent, null, 2)}</pre>}
    </section>
  )
}

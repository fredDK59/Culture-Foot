'use client'
import { useEffect, useState } from 'react'

export function CultureFootDiscoveryEngine() {
  const [items, setItems] = useState<any[]>([])
  useEffect(() => {
    fetch('/api/v4/discovery').then(r=>r.json()).then(d=>setItems(d.items ?? []))
  }, [])
  return (
    <section className="rounded-3xl border border-yellow-500/20 bg-slate-950/80 p-6">
      <p className="text-xs uppercase tracking-[0.25em] text-yellow-300">Découverte</p>
      <h2 className="mt-2 text-2xl font-semibold text-white">Continuez Votre Voyage</h2>
      <p className="mt-2 text-sm text-slate-400">Des portes possibles, jamais un parcours imposé.</p>
      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        {items.map(item => (
          <article key={item.entityId} className="rounded-2xl border border-slate-800 p-4">
            <div className="text-sm font-medium text-white">{item.topic}</div>
            <p className="mt-2 text-xs text-slate-400">{item.reason}</p>
          </article>
        ))}
      </div>
    </section>
  )
}

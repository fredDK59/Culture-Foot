'use client';

import { useState } from 'react';

type Result = {
  slug: string;
  name: string;
};

export default function CultureFootSearchCompare() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Result[]>([]);
  const [message, setMessage] = useState('');

  async function search() {
    const q = query.trim();
    if (!q) return;

    setMessage('Recherche en cours…');

    try {
      const response = await fetch(`/api/v1/search?q=${encodeURIComponent(q)}`);
      const payload = await response.json();

      setResults(payload.results ?? []);

      if (payload.intents?.length) {
        const intent = payload.intents[0];
        setMessage(
          `Comparaison détectée : ${intent.leftQuery} ↔ ${intent.rightQuery}`
        );
      } else {
        setMessage(`${payload.results?.length ?? 0} résultat(s)`);
      }
    } catch {
      setMessage('Recherche indisponible pour le moment.');
    }
  }

  return (
    <section className="rounded-[2rem] border border-sky-400/20 bg-[#07111f]/90 p-5 md:p-8">
      <p className="text-xs font-bold uppercase tracking-[0.22em] text-sky-300/70">
        Recherche Culture Foot
      </p>

      <h2 className="mt-2 text-3xl font-black text-white">
        Que Voulez-Vous Découvrir ?
      </h2>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') search();
          }}
          placeholder="Mbappé, Haaland, comparer Mbappé et Haaland…"
          className="min-h-12 flex-1 rounded-2xl border border-sky-400/20 bg-slate-950 px-4 text-white outline-none placeholder:text-sky-200/30"
          aria-label="Recherche Culture Foot"
        />
        <button
          type="button"
          onClick={search}
          className="min-h-12 rounded-2xl bg-sky-500 px-6 font-bold text-slate-950 transition hover:bg-sky-300"
        >
          Rechercher
        </button>
      </div>

      {message && (
        <p className="mt-4 text-sm text-sky-200/65" aria-live="polite">
          {message}
        </p>
      )}

      {results.length > 0 && (
        <div className="mt-6 grid gap-3 md:grid-cols-2">
          {results.map((result) => (
            <article
              key={result.slug}
              className="rounded-2xl border border-sky-400/10 bg-slate-950/55 p-4"
            >
              <h3 className="font-extrabold text-white">{result.name}</h3>
              <div className="mt-3 flex gap-2">
                <a
                  href={`/joueurs/${result.slug}`}
                  className="rounded-full border border-sky-400/20 px-3 py-1.5 text-xs font-semibold text-sky-200"
                >
                  Découvrir
                </a>
                <a
                  href={`/comparateur?player=${result.slug}`}
                  className="rounded-full bg-emerald-400/15 px-3 py-1.5 text-xs font-semibold text-emerald-300"
                >
                  Comparer
                </a>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

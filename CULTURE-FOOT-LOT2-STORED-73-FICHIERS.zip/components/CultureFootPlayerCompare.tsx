'use client';

import { useMemo, useState } from 'react';

type Player = {
  slug: string;
  name: string;
};

type Observation = {
  player: string;
  playerName: string;
  season: string;
  value: number | null;
  evidenceStatus?: string;
};

type Props = {
  left: Player;
  right: Player;
  observations: Observation[];
  scope?: string;
  metric?: string;
};

export default function CultureFootPlayerCompare({
  left,
  right,
  observations,
  scope = 'LIGUE_1',
  metric = 'GOALS',
}: Props) {
  const [season, setSeason] = useState<string>('ALL');

  const seasons = useMemo(
    () => ['ALL', ...Array.from(new Set(observations.map((x) => x.season)))],
    [observations]
  );

  const filtered = observations.filter((x) => season === 'ALL' || x.season === season);

  const valueFor = (slug: string) => {
    const values = filtered
      .filter((x) => x.player === slug && typeof x.value === 'number')
      .map((x) => Number(x.value));
    if (!values.length) return null;
    return season === 'ALL' ? values.reduce((a, b) => a + b, 0) : values[0];
  };

  const leftValue = valueFor(left.slug);
  const rightValue = valueFor(right.slug);
  const max = Math.max(leftValue ?? 0, rightValue ?? 0, 1);

  return (
    <section className="rounded-[2rem] border border-sky-400/20 bg-[#07111f]/90 p-5 md:p-8">
      <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.22em] text-sky-300/70">
            Comparateur Culture Foot
          </p>
          <h2 className="mt-2 text-3xl font-black tracking-tight text-white">
            {left.name} <span className="text-sky-400">Vs</span> {right.name}
          </h2>
          <p className="mt-2 text-sm text-sky-200/60">
            Même indicateur · même périmètre · même définition
          </p>
        </div>

        <label className="text-xs font-semibold uppercase tracking-wider text-sky-200">
          Saison
          <select
            value={season}
            onChange={(e) => setSeason(e.target.value)}
            className="mt-2 block min-w-40 rounded-xl border border-sky-400/20 bg-slate-900 px-3 py-2 text-sm text-white outline-none"
          >
            {seasons.map((item) => (
              <option key={item} value={item}>
                {item === 'ALL' ? 'Toutes Les Saisons' : item}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-2">
        {[{ p: left, v: leftValue }, { p: right, v: rightValue }].map(({ p, v }) => {
          const width = v === null ? 0 : Math.max(4, Math.round((v / max) * 100));
          return (
            <article key={p.slug} className="rounded-2xl border border-sky-400/10 bg-slate-950/55 p-5">
              <div className="flex items-center justify-between gap-4">
                <h3 className="text-lg font-extrabold text-sky-100">{p.name}</h3>
                <strong className="text-3xl font-black text-white">
                  {v === null ? '—' : v}
                </strong>
              </div>
              <div className="mt-5 h-3 overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full rounded-full bg-emerald-400 transition-all duration-500"
                  style={{ width: `${width}%` }}
                />
              </div>
            </article>
          );
        })}
      </div>

      <div className="mt-6 flex flex-wrap gap-2 text-xs text-sky-200/55">
        <span>{scope}</span>
        <span>•</span>
        <span>{metric}</span>
        <span>•</span>
        <span>Source Et Statut Conservés</span>
      </div>
    </section>
  );
}

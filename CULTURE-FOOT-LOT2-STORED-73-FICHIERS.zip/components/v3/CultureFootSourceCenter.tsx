'use client'
import { useEffect, useState } from 'react'

export function CultureFootSourceCenter() {
  const [status, setStatus] = useState<any>(null)
  useEffect(() => {
    fetch('/api/v3/sources/status').then(r => r.json()).then(setStatus).catch(() => setStatus({status:'unavailable'}))
  }, [])
  return (
    <section className="rounded-3xl border border-blue-500/20 bg-slate-950/70 p-6">
      <p className="text-xs uppercase tracking-[0.25em] text-blue-300">Culture Foot Data</p>
      <h2 className="mt-2 text-2xl font-semibold text-white">Centre Des Sources</h2>
      <p className="mt-2 text-sm text-slate-400">Collecte, contrôle, provenance et publication.</p>
      <pre className="mt-5 overflow-auto rounded-2xl bg-black/30 p-4 text-xs text-slate-300">{JSON.stringify(status, null, 2)}</pre>
    </section>
  )
}

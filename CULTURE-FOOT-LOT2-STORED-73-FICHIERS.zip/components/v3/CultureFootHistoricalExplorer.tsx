'use client'
import { useState } from 'react'

export function CultureFootHistoricalExplorer() {
  const [year, setYear] = useState(1998)
  return (
    <section className="rounded-3xl border border-purple-500/20 bg-slate-950/70 p-6">
      <p className="text-xs uppercase tracking-[0.25em] text-purple-300">Machine Temporelle</p>
      <h2 className="mt-2 text-2xl font-semibold text-white">Explorateur Historique</h2>
      <input aria-label="Année" type="range" min="1900" max="2026" value={year} onChange={e=>setYear(Number(e.target.value))} className="mt-6 w-full" />
      <div className="mt-4 text-5xl font-bold text-white">{year}</div>
      <p className="mt-2 text-sm text-slate-400">Reconstitution selon les données réellement disponibles pour cette période.</p>
    </section>
  )
}

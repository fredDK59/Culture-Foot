'use client'
export function CultureFootMediaArchive() {
  return (
    <section className="rounded-3xl border border-orange-500/20 bg-slate-950/70 p-6">
      <p className="text-xs uppercase tracking-[0.25em] text-orange-300">Archives</p>
      <h2 className="mt-2 text-2xl font-semibold text-white">Médias & Archives</h2>
      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        {['Photos','Vidéos','Documents'].map(x => <div key={x} className="rounded-2xl border border-slate-800 p-4 text-slate-200">{x}</div>)}
      </div>
    </section>
  )
}

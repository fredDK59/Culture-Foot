'use client'
import { useEffect, useState } from 'react'

export function CultureFootQualityCenter() {
  const [data, setData] = useState<any>(null)
  useEffect(() => {
    fetch('/api/v3/quality').then(r => r.json()).then(setData).catch(() => setData(null))
  }, [])
  return (
    <section className="rounded-3xl border border-emerald-500/20 bg-slate-950/70 p-6">
      <p className="text-xs uppercase tracking-[0.25em] text-emerald-300">Culture Foot Data</p>
      <h2 className="mt-2 text-2xl font-semibold text-white">Qualité Des Données</h2>
      <p className="mt-2 text-sm text-slate-400">Une donnée douteuse doit être signalée, jamais maquillée.</p>
      <div className="mt-5 grid gap-2 sm:grid-cols-2">{(data?.checks ?? []).map((x:string) => <div key={x} className="rounded-xl border border-slate-800 p-3 text-sm text-slate-300">{x}</div>)}</div>
    </section>
  )
}

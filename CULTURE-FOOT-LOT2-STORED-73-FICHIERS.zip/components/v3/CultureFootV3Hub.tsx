import { CultureFootSourceCenter } from './CultureFootSourceCenter'
import { CultureFootQualityCenter } from './CultureFootQualityCenter'
import { CultureFootHistoricalExplorer } from './CultureFootHistoricalExplorer'
import { CultureFootMediaArchive } from './CultureFootMediaArchive'

export function CultureFootV3Hub() {
  return (
    <main className="mx-auto max-w-6xl space-y-6 px-4 py-10">
      <header>
        <p className="text-sm font-semibold tracking-[0.25em] text-blue-300">CULTURE FOOT V3</p>
        <h1 className="mt-3 text-4xl font-bold text-white">L’Infrastructure Footballistique Vivante</h1>
        <p className="mt-3 max-w-3xl text-slate-400">Données, histoire, géographie, médias et analyses reliés dans une même encyclopédie en perpétuelle évolution.</p>
      </header>
      <div className="grid gap-6 lg:grid-cols-2">
        <CultureFootSourceCenter />
        <CultureFootQualityCenter />
        <CultureFootHistoricalExplorer />
        <CultureFootMediaArchive />
      </div>
    </main>
  )
}

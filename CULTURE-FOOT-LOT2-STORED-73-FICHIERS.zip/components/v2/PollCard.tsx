"use client";
import { useState } from "react";

type Option = { id:string; label:string; position:number; _count:{votes:number} };
type Poll = { id:string; question:string; category:string; options:Option[] };
export default function PollCard({poll}:{poll:Poll}) {
  const [selected,setSelected]=useState(""); const [sent,setSent]=useState(false); const [busy,setBusy]=useState(false);
  const total=poll.options.reduce((n,o)=>n+o._count.votes,0);
  async function vote(){ if(!selected||busy)return; setBusy(true); try { const r=await fetch("/api/v2/polls",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({pollId:poll.id,optionId:selected})}); if(r.ok)setSent(true); } finally {setBusy(false)} }
  return <article className="v2-card poll-card"><div className="v2-kicker">Sondage · {poll.category}</div><h3>{poll.question}</h3><div className="poll-options">{poll.options.map(o=><label key={o.id} className="poll-option"><input type="radio" name={poll.id} value={o.id} checked={selected===o.id} onChange={()=>setSelected(o.id)}/><span>{o.label}</span><small>{total?Math.round(o._count.votes/total*100):0}%</small></label>)}</div><button className="v2-button" onClick={vote} disabled={!selected||busy||sent}>{sent?"Vote Enregistré ✓":busy?"Enregistrement…":"Voter"}</button>{sent&&<p className="v2-muted">Merci. Le vote devient une nouvelle donnée à explorer.</p>}</article>
}

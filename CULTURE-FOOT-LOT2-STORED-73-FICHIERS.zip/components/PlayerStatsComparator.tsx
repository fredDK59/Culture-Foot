'use client';

import { useMemo, useState } from 'react';

type Row = {
  season: string;
  label: string;
  value: number;
  evidenceStatus?: string;
};

type Props = {
  title?: string;
  rows: Row[];
  unit?: string;
  color?: 'green' | 'blue';
};

export default function PlayerStatsComparator({
  title = 'Évolution Statistique',
  rows,
  unit = '',
  color = 'green',
}: Props) {
  const [metric, setMetric] = useState<'value'>('value');
  const max = Math.max(...rows.map((r) => r.value), 1);

  const colorClass = color === 'blue' ? 'border-sky-400/30' : 'border-emerald-400/30';

  return (
    <section className={`rounded-3xl border ${colorClass} bg-slate-950/55 p-5 md:p-7`}>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-sky-300/75">
            Données
          </p>
          <h2 className="mt-1 text-2xl font-black tracking-tight text-white">{title}</h2>
        </div>
        <div className="rounded-full border border-sky-400/20 bg-sky-400/5 px-3 py-1 text-xs text-sky-200">
          {rows.length} saisons
        </div>
      </div>

      <div className="space-y-3" aria-label={title}>
        {rows.map((row) => {
          const width = Math.max(3, Math.round((row.value / max) * 100));
          return (
            <button
              key={row.season}
              type="button"
              className="group block w-full text-left"
              aria-label={`${row.label}: ${row.value}${unit}`}
            >
              <div className="mb-1 flex items-center justify-between gap-3 text-xs">
                <span className="font-semibold text-sky-200">{row.label}</span>
                <span className="font-bold text-white">
                  {row.value}{unit}
                </span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full rounded-full bg-emerald-400 transition-all duration-500 group-hover:bg-sky-400"
                  style={{ width: `${width}%` }}
                />
              </div>
            </button>
          );
        })}
      </div>

      <p className="mt-5 text-xs leading-5 text-sky-200/55">
        Les valeurs restent rattachées à leur saison, leur périmètre et leur niveau de preuve.
        Une statistique absente n’est pas remplacée par une estimation automatique.
      </p>
    </section>
  );
}

export const v3Routes = {
  hub: '/v3',
  geography: '/api/v3/geography',
  analytics: '/api/v3/analytics',
  sources: '/api/v3/sources/status',
  quality: '/api/v3/quality',
  media: '/api/v3/media',
} as const

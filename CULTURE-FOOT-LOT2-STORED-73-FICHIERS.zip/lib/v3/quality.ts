export type QualityIssue = {
  entityType: string
  entityId?: string
  field?: string
  severity: "INFO" | "WARNING" | "ERROR" | "CRITICAL"
  code: string
  message: string
}

export function detectNumericAnomalies(values: number[], field: string): QualityIssue[] {
  const issues: QualityIssue[] = []
  for (let i = 1; i < values.length; i++) {
    if (!Number.isFinite(values[i])) {
      issues.push({
        entityType: "metric",
        field,
        severity: "ERROR",
        code: "NON_FINITE",
        message: `${field}: valeur non numérique à l'index ${i}`,
      })
    }
  }
  return issues
}

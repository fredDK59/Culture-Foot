export type SeriesPoint = { year: number; value: number | null }

export function yoyChange(points: SeriesPoint[]) {
  return points.map((p, i) => {
    const prev = points[i - 1]?.value
    if (prev == null || p.value == null || prev === 0) return { ...p, change: null }
    return { ...p, change: ((p.value - prev) / Math.abs(prev)) * 100 }
  })
}

export function normalizePerCapacity(value: number | null, capacity: number | null) {
  if (value == null || !capacity || capacity <= 0) return null
  return value / capacity
}

export function rankWithTies(values: { id: string; value: number }[]) {
  const sorted = [...values].sort((a, b) => b.value - a.value)
  let last: number | null = null
  let rank = 0
  return sorted.map((item, index) => {
    if (last !== item.value) rank = index + 1
    last = item.value
    return { ...item, rank }
  })
}

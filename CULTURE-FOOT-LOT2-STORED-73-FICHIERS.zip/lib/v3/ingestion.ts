export type SyncInput = {
  sourceId: string
  cursor?: string
  checksum?: string
  records: unknown[]
}

export type SyncResult = {
  status: "SUCCESS" | "PARTIAL" | "FAILED"
  seen: number
  created: number
  updated: number
  rejected: number
}

export function stableRecordHash(record: unknown) {
  const json = JSON.stringify(record, Object.keys((record as object) || {}).sort())
  let hash = 2166136261
  for (let i = 0; i < json.length; i++) {
    hash ^= json.charCodeAt(i)
    hash = Math.imul(hash, 16777619)
  }
  return (hash >>> 0).toString(16).padStart(8, "0")
}

export function runIdempotentSync(input: SyncInput): SyncResult {
  const seen = input.records.length
  const valid = input.records.filter(Boolean)
  return {
    status: valid.length === seen ? "SUCCESS" : "PARTIAL",
    seen,
    created: valid.length,
    updated: 0,
    rejected: seen - valid.length,
  }
}

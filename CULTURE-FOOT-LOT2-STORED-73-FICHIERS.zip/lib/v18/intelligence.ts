export type AnalysisInput={dataset:string; question:string; filters:Record<string,string|number|boolean>; methodology:string; sources:string[]}
export type AnalysisResult={answer:string; caveats:string[]; reproducible:boolean; inputs:AnalysisInput}
export const intelligenceContract={version:'18.0.0',principles:['facts-before-interpretation','methodology-visible','uncertainty-visible','reproducible-results','no-fabricated-data']}
export function validateAnalysis(input:AnalysisInput){return {ok:Boolean(input.dataset&&input.question&&input.methodology&&input.sources.length),missing:[!input.dataset?'dataset':null,!input.question?'question':null,!input.methodology?'methodology':null,!input.sources.length?'sources':null].filter(Boolean)}}

export type DataProvider = { id:string; name:string; priority:number; scopes:string[]; status:'planned'|'connected'|'paused'|'retired' }
export type FederationPolicy = { canonicalRule:string; dedupeRule:string; conflictRule:string; evidenceRule:string; replayable:boolean }
export const dataFederation = {
  version:'14.0.0',
  providers:[
    {id:'official',name:'Sources Officielles',priority:1,scopes:['competitions','clubs','players','matches','stadiums'],status:'planned'},
    {id:'specialist',name:'Sources Spécialistes',priority:2,scopes:['statistics','history','transfers'],status:'planned'},
    {id:'archives',name:'Archives Documentaires',priority:3,scopes:['media','history','stadiums'],status:'planned'},
  ] satisfies DataProvider[],
  policy:{canonicalRule:'entity identity is canonical before metrics',dedupeRule:'stable source keys + normalized identity',conflictRule:'retain competing observations; never silently overwrite',evidenceRule:'publish provenance and evidence status',replayable:true} satisfies FederationPolicy,
}
export function providerFor(scope:string){return dataFederation.providers.filter(p=>p.scopes.includes(scope)).sort((a,b)=>a.priority-b.priority)}

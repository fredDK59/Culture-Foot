export const publicBetaContract={version:'17.0.0',gates:[
  {key:'identity',label:'Identités canoniques',required:true},
  {key:'provenance',label:'Provenance des données',required:true},
  {key:'mobile',label:'Expérience mobile',required:true},
  {key:'search',label:'Recherche',required:true},
  {key:'discovery',label:'Découverte optionnelle',required:true},
  {key:'privacy',label:'Parcours sans profilage',required:true},
  {key:'monitoring',label:'Monitoring',required:true},
]}
export function betaDecision(results:Record<string,boolean>){const failed=publicBetaContract.gates.filter(g=>g.required&&!results[g.key]);return {ready:failed.length===0,failed}}

import { canonicalCatalog } from './catalog'

export const productContract = {
  version: '11.0.0',
  principle: 'INTENTION → RÉPONSE → CURIOSITÉS POSSIBLES → CHOIX',
  doors: [
    {id:'search', label:'Je Sais Ce Que Je Cherche', href:'/recherche'},
    {id:'explore', label:'Je Veux Explorer', href:'/geographie'},
    {id:'surprise', label:'Étonnez-Moi', href:'/jeux'},
  ],
  canonicalEntities: canonicalCatalog.length,
}

export type CatalogEntity = {
  id: string
  type: 'player'|'club'|'competition'|'season'|'match'|'stadium'|'transfer'
  slug: string
  label: string
  subtitle?: string
  tags: string[]
  href: string
}

export const canonicalCatalog: CatalogEntity[] = [
  {id:'player-mbappe',type:'player',slug:'kylian-mbappe',label:'Kylian Mbappé',subtitle:'Attaquant — France',tags:['joueur','france','psg','real-madrid'],href:'/joueurs/kylian-mbappe'},
  {id:'club-psg',type:'club',slug:'paris-saint-germain',label:'Paris Saint-Germain',subtitle:'Paris — France',tags:['club','france','ligue-1'],href:'/clubs/paris-saint-germain'},
  {id:'club-monaco',type:'club',slug:'as-monaco',label:'AS Monaco',subtitle:'Monaco — France',tags:['club','france','ligue-1'],href:'/clubs/as-monaco'},
  {id:'competition-ligue-1',type:'competition',slug:'ligue-1',label:'Ligue 1',subtitle:'France',tags:['competition','france'],href:'/championnats'},
  {id:'stadium-parc',type:'stadium',slug:'parc-des-princes',label:'Parc des Princes',subtitle:'Paris — France',tags:['stade','psg','paris'],href:'/stades/parc-des-princes'},
  {id:'match-psg-monaco-2018',type:'match',slug:'psg-monaco-2018',label:'PSG — Monaco, 7–1',subtitle:'15 avril 2018',tags:['match','psg','monaco','2018'],href:'/matchs'},
  {id:'transfer-monaco-psg',type:'transfer',slug:'mbappe-monaco-psg',label:'Mbappé — Monaco → PSG',subtitle:'2017 — montant documenté : 180 M€',tags:['transfert','mbappe','monaco','psg'],href:'/transferts'},
]

export function searchCatalog(query: string) {
  const q = query.trim().toLocaleLowerCase('fr-FR')
  if (!q) return canonicalCatalog.slice(0, 8)
  return canonicalCatalog.filter(e => [e.label,e.subtitle,e.slug,...e.tags].join(' ').toLocaleLowerCase('fr-FR').includes(q)).slice(0, 12)
}

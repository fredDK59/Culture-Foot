export type CoverageCell={entityType:string; geography:string; period:string; completeness:number; evidence:'verified'|'partial'|'unknown'}
export const coverageContract={version:'19.0.0',dimensions:['entityType','geography','period','metric'],rule:'coverage is measured, never assumed'}
export function coverageLabel(value:number){if(value>=.95)return 'Très Haute';if(value>=.75)return 'Haute';if(value>=.5)return 'Partielle';return 'Faible'}

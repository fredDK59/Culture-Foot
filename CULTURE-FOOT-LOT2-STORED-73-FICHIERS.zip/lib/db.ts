import "dotenv/config";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "@/generated/prisma/client";

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };
const connectionString = process.env.DATABASE_URL ?? "postgresql://placeholder:placeholder@localhost:5432/culture_foot";

const baseDb =
  globalForPrisma.prisma ??
  new PrismaClient({ adapter: new PrismaPg({ connectionString }) });

// Preview-friendly behavior: Vercel can render the visual product before PostgreSQL
// is connected. Read queries return empty data instead of crashing the preview.
// Once DATABASE_URL is configured, Prisma behaves normally.
const readMethods = new Set(["findFirst", "findFirstOrThrow", "findUnique", "findUniqueOrThrow", "findMany", "count", "aggregate", "groupBy"]);
const emptyFor = (method: string) => {
  if (method === "findMany" || method === "groupBy") return [];
  if (method === "count") return 0;
  return method.endsWith("OrThrow") ? null : null;
};

const modelCache = new Map<PropertyKey, unknown>();
const dbProxy = new Proxy(baseDb as PrismaClient, {
  get(target, prop, receiver) {
    const model = Reflect.get(target, prop, receiver);
    if (!model || typeof model !== "object") return model;
    if (modelCache.has(prop)) return modelCache.get(prop);

    const wrapped = new Proxy(model as object, {
      get(modelTarget, methodProp, methodReceiver) {
        const method = Reflect.get(modelTarget, methodProp, methodReceiver);
        if (typeof method !== "function" || !readMethods.has(String(methodProp))) return method;
        return async (...args: unknown[]) => {
          try {
            return await method.apply(modelTarget, args);
          } catch (error) {
            if (!process.env.DATABASE_URL) {
              if (process.env.NODE_ENV !== "production") {
                console.warn(`[Culture Foot] DATABASE_URL not configured; preview fallback for ${String(prop)}.${String(methodProp)}`);
              }
              return emptyFor(String(methodProp));
            }
            throw error;
          }
        };
      },
    });
    modelCache.set(prop, wrapped);
    return wrapped;
  },
});

export const db = dbProxy;

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = baseDb;

export type TimeContext = {
  year: number
  season?: string
  label: string
  entityType: string
  entityId: string
  confidence: 'VERIFIED' | 'RECONSTRUCTED' | 'PARTIAL'
}

export function makeTimeContext(input: Omit<TimeContext, 'label'> & { label?: string }): TimeContext {
  return {
    ...input,
    label: input.label ?? `Football ${input.year}`,
  }
}

export function isWithinContext(dateIso: string, year: number) {
  const yearFromDate = new Date(dateIso).getUTCFullYear()
  return yearFromDate === year
}

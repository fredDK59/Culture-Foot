import type { Evidence } from './contracts'

export type QualityCheck = {
  code: string
  ok: boolean
  severity: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL'
  message: string
}

export function checkEvidence(evidence: Evidence | null | undefined): QualityCheck {
  if (!evidence || evidence === 'UNKNOWN') {
    return { code: 'MISSING_EVIDENCE', ok: false, severity: 'WARNING', message: 'La donnée n’a pas de niveau de preuve explicite.' }
  }
  if (evidence === 'DISPUTED') {
    return { code: 'DISPUTED_EVIDENCE', ok: false, severity: 'ERROR', message: 'La donnée est signalée comme disputée.' }
  }
  return { code: 'EVIDENCE_PRESENT', ok: true, severity: 'INFO', message: 'Niveau de preuve renseigné.' }
}

export function anomalyDelta(current: number | null, previous: number | null) {
  if (current === null || previous === null || previous === 0) return null
  return (current - previous) / Math.abs(previous)
}

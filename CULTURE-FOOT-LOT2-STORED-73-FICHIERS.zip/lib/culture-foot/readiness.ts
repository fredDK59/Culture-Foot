export type ReadinessItem = {
  key: string
  ok: boolean
  note: string
}

export function readinessReport(items: ReadinessItem[]) {
  const errors = items.filter((item) => !item.ok)
  return {
    ready: errors.length === 0,
    total: items.length,
    passed: items.length - errors.length,
    blockers: errors,
  }
}

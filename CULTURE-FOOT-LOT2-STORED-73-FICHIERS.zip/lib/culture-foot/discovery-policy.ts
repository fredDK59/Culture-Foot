import type { CanonicalEntity, DiscoveryProposal } from './contracts'

export function rankCuriosities(
  proposals: DiscoveryProposal[],
  max = 6,
): DiscoveryProposal[] {
  return proposals
    .filter((item) => item.optional === true && item.entity.id && item.reason)
    .slice(0, Math.max(0, Math.min(max, 12)))
}

export function buildDiscovery(
  intent: string,
  answer: CanonicalEntity | null,
  proposals: DiscoveryProposal[],
) {
  return {
    intent,
    answer,
    proposals: rankCuriosities(proposals),
    principle: 'PROPOSE_NOT_IMPOSE' as const,
  }
}

export type Evidence =
  | 'VERIFIED'
  | 'ESTIMATED'
  | 'RECONSTRUCTED'
  | 'PARTIAL'
  | 'UNKNOWN'
  | 'DISPUTED'

export type EntityType =
  | 'player'
  | 'club'
  | 'competition'
  | 'season'
  | 'match'
  | 'stadium'
  | 'transfer'
  | 'analysis'
  | 'media'
  | 'national-team'

export type SourceRef = {
  id: string
  name?: string
  type?: string
  retrievedAt?: string
}

export type CanonicalEntity = {
  id: string
  type: EntityType
  label: string
  status?: string
  updatedAt?: string
  evidence?: Evidence
  sourceRefs?: SourceRef[]
  links?: Array<{ label: string; href: string; kind?: string }>
}

export type DiscoveryProposal = {
  entity: CanonicalEntity
  reason: string
  relation?: string
  optional: true
}

export type DiscoveryResponse = {
  intent: string
  answer: CanonicalEntity | null
  proposals: DiscoveryProposal[]
  principle: 'PROPOSE_NOT_IMPOSE'
}

import { canonicalCatalog, type CatalogEntity } from '../v11/catalog'

const relations: Record<string,string[]> = {
  player: ['club','transfer','match','stadium','competition'],
  club: ['player','stadium','competition','match','transfer'],
  competition: ['club','player','season','match'],
  season: ['competition','club','player','match'],
  match: ['player','club','stadium','competition'],
  stadium: ['club','match','city'],
  transfer: ['player','club','season','economy'],
}

export function proposeDiscovery(answer: CatalogEntity | null, limit = 5) {
  if (!answer) return canonicalCatalog.slice(0, limit).map(entity => ({entity, reason:'Point de départ possible', relation:'exploration', optional:true as const}))
  const allowed = new Set(relations[answer.type] ?? [])
  const proposals = canonicalCatalog.filter(entity => entity.id !== answer.id && (allowed.has(entity.type) || entity.tags.some(tag => answer.tags.includes(tag))))
  return proposals.slice(0, limit).map(entity => ({
    entity,
    reason: reasonFor(answer, entity),
    relation: `${answer.type}→${entity.type}`,
    optional: true as const,
  }))
}

function reasonFor(from: CatalogEntity, to: CatalogEntity) {
  if (from.tags.some(tag => to.tags.includes(tag))) return `Un Lien Naturel Avec ${from.label}`
  return `Une Autre Porte À Ouvrir Depuis ${from.label}`
}

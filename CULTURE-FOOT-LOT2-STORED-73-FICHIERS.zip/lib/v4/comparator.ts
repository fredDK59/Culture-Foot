export type ComparisonMetric = {
  key: string
  label: string
  unit?: string
  value: number | null
  source?: string
}

export type ComparableEntity = {
  id: string
  type: string
  label: string
  metrics: ComparisonMetric[]
}

export function compareEntities(entities: ComparableEntity[], metricKey: string) {
  return entities.map(entity => ({
    id: entity.id,
    type: entity.type,
    label: entity.label,
    metric: entity.metrics.find(m => m.key === metricKey)?.value ?? null,
  }))
}

export type SearchFilters = {
  entityTypes?: string[]
  country?: string
  seasonFrom?: string
  seasonTo?: string
  minValue?: number
  maxValue?: number
  tags?: string[]
}

export function normalizeQuery(query: string) {
  return query.trim().replace(/\s+/g, " ")
}

export function buildSearchIntent(query: string, filters: SearchFilters = {}) {
  const normalized = normalizeQuery(query)
  return {
    query: normalized,
    filters,
    mode: normalized ? "semantic" : "browse",
  }
}

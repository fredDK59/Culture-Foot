export const locales = ["fr", "en"] as const
export type Locale = typeof locales[number]

export const labels: Record<Locale, Record<string,string>> = {
  fr: {
    explore: "Explorer",
    search: "Recherche",
    surprise: "Étonnez-Moi",
    journey: "Mon Parcours",
    discoveries: "Mes Découvertes",
    compare: "Comparer",
    sources: "Sources",
  },
  en: {
    explore: "Explore",
    search: "Search",
    surprise: "Surprise Me",
    journey: "My Journey",
    discoveries: "My Discoveries",
    compare: "Compare",
    sources: "Sources",
  },
}

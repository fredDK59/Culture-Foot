export const v4Routes = {
  hub: '/v4',
  discovery: '/api/v4/discovery',
  search: '/api/v4/search',
  compare: '/api/v4/compare',
  realtime: '/api/v4/realtime',
} as const

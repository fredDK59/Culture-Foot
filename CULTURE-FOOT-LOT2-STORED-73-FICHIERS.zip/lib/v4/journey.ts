export type JourneyItem = {
  id: string
  type: string
  label: string
  visitedAt: string
  source?: string
}

export function exportJourney(items: JourneyItem[]) {
  return JSON.stringify({
    format: "culture-foot-journey",
    version: 1,
    exportedAt: new Date().toISOString(),
    items,
  }, null, 2)
}

export function importJourney(raw: string): JourneyItem[] {
  const parsed = JSON.parse(raw)
  if (!parsed || parsed.format !== "culture-foot-journey" || !Array.isArray(parsed.items)) {
    throw new Error("Format de parcours Culture Foot invalide")
  }
  return parsed.items
}

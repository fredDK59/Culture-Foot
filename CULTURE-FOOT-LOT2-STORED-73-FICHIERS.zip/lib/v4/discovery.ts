export type DiscoverySignal = {
  entityType: string
  entityId: string
  topic: string
  reason: string
  score: number
}

export type DiscoveryCandidate = DiscoverySignal & {
  diversityKey: string
}

export function diversifyDiscovery(candidates: DiscoveryCandidate[], limit = 6) {
  const selected: DiscoveryCandidate[] = []
  const seen = new Set<string>()
  for (const candidate of [...candidates].sort((a,b)=>b.score-a.score)) {
    if (selected.length >= limit) break
    if (seen.has(candidate.diversityKey)) continue
    seen.add(candidate.diversityKey)
    selected.push(candidate)
  }
  return selected
}

export function explainDiscovery(candidate: DiscoverySignal) {
  return `${candidate.reason} — proposition facultative`
}

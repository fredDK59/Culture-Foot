export type FootballEvent = {
  id: string
  type: string
  entityType: string
  entityId: string
  occurredAt: string
  payload: Record<string, unknown>
}

export function invalidateForEvent(event: FootballEvent) {
  const prefixes: Record<string,string[]> = {
    MATCH_COMPLETED: ["/matches", "/standings", "/players", "/clubs"],
    PLAYER_TRANSFERRED: ["/players", "/transfers", "/clubs", "/market-values"],
    MARKET_VALUE_UPDATED: ["/players", "/market-values"],
    STADIUM_EVENT: ["/stadiums", "/attendance"],
  }
  return prefixes[event.type] ?? []
}

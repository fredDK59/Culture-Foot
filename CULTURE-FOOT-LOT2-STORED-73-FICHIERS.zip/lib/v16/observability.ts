export type HealthSignal = {key:string; severity:'info'|'warning'|'error'|'critical'; message:string; value?:number}
export function summarizeSignals(signals:HealthSignal[]){return {critical:signals.filter(s=>s.severity==='critical').length,error:signals.filter(s=>s.severity==='error').length,warning:signals.filter(s=>s.severity==='warning').length,ok:signals.every(s=>s.severity==='info')}}
export const observabilityContract={version:'16.0.0',tracks:['ingestion','database','search','discovery','media','api','ui'],requiresCorrelationId:true,requiresAuditTrail:true}

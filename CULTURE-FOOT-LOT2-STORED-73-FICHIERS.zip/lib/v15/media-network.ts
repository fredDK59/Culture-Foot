export type MediaRecord = { id:string; kind:'photo'|'video'|'audio'|'document'|'archive'; entityType:string; entityId:string; title:string; source:string; rights:'unknown'|'public-domain'|'licensed'|'permission-required'; capturedAt?:string }
export const mediaNetwork = {version:'15.0.0',rightsRequired:true,derivativesAllowed:false,recordsMustKeepOriginalSource:true}
export function mediaStatus(record:MediaRecord){return {publishable:record.rights==='licensed'||record.rights==='public-domain',needsReview:record.rights==='unknown'||record.rights==='permission-required'}}

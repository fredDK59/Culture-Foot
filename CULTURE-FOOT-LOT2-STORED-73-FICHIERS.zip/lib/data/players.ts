export type Player = {
  slug: string;
  name: string;
  nationality: string;
  birthDate: string;
  currentClub: string;
  franceCaps: number;
  careerGoals: number;
  marketValue: string;
};

const players: Record<string, Player> = {
  "kylian-mbappe": {
    slug: "kylian-mbappe",
    name: "Kylian Mbappé",
    nationality: "France",
    birthDate: "20 Décembre 1998",
    currentClub: "Real Madrid",
    franceCaps: 103,
    careerGoals: 268,
    marketValue: "€180M",
  },
};

export function getPlayer(slug: string) {
  return players[slug];
}
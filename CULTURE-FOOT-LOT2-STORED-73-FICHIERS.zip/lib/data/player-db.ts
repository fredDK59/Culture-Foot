import { db } from "@/lib/db";

export async function getPlayerFromDb(slug: string) {
  return db.player.findFirst({
    where: { person: { slug } },
    include: {
      person: true,
      currentClub: true,
      spells: { include: { club: true }, orderBy: { startDate: "asc" } },
      seasonStats: {
        include: { season: true, club: true, source: true },
        orderBy: { observedAt: "desc" },
      },
      seasonMetrics: {
        include: { season: true, club: true, competition: true, nationalTeam: true, source: true },
        orderBy: { season: { startDate: "asc" } },
      },
      marketValues: {
        include: { source: true },
        orderBy: { observedAt: "desc" },
      },
      honours: { include: { source: true } },
      appearances: {
        include: {
          match: {
            include: { homeClub: true, awayClub: true, stadium: true, competition: true, season: true },
          },
        },
        orderBy: { match: { kickoffAt: "desc" } },
      },
    },
  });
}

export type EntityRoute = {
  href: string;
  label: string;
};

const encode = (value: string) => encodeURIComponent(value);

export function getEntityRoute(type: string, id: string): EntityRoute {
  const routes: Record<string, (value: string) => EntityRoute> = {
    player: (value) => ({ href: `/joueurs/${encode(value)}`, label: 'Voir Le Joueur' }),
    players: (value) => ({ href: `/joueurs/${encode(value)}`, label: 'Voir Le Joueur' }),
    club: (value) => ({ href: `/clubs/${encode(value)}`, label: 'Voir Le Club' }),
    clubs: (value) => ({ href: `/clubs/${encode(value)}`, label: 'Voir Le Club' }),
    competition: (value) => ({ href: `/championnats/${encode(value)}`, label: 'Voir Le Championnat' }),
    competitions: (value) => ({ href: `/championnats/${encode(value)}`, label: 'Voir Le Championnat' }),
    stadium: (value) => ({ href: `/stades/${encode(value)}`, label: 'Voir Le Stade' }),
    stadiums: (value) => ({ href: `/stades/${encode(value)}`, label: 'Voir Le Stade' }),
    match: (value) => ({ href: `/matchs/${encode(value)}`, label: 'Voir Le Match' }),
    matches: (value) => ({ href: `/matchs/${encode(value)}`, label: 'Voir Le Match' }),
    transfer: (value) => ({ href: `/transferts/${encode(value)}`, label: 'Voir Le Transfert' }),
    transfers: (value) => ({ href: `/transferts/${encode(value)}`, label: 'Voir Le Transfert' }),
  };

  return routes[type.toLowerCase()]?.(id) ?? {
    href: `/recherche?q=${encode(id)}`,
    label: 'Explorer Ce Sujet',
  };
}

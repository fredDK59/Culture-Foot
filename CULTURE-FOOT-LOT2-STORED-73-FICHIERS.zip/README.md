# Culture Foot V1

Premier vertical slice technique : page Joueur.

## Lancer

```bash
pnpm install
pnpm dev
```

Puis ouvrir :

http://localhost:3000/joueurs/kylian-mbappe

## Structure

- `app/` : routes et layouts Next.js
- `app/joueurs/[slug]/page.tsx` : page joueur réutilisable
- `lib/data/players.ts` : données temporaires du vertical slice
- `app/globals.css` : ADN visuel commun

## Étape suivante

Remplacer les données temporaires par PostgreSQL/API sans changer la structure de la page.

Les chiffres actuellement présents dans `players.ts` sont des placeholders de construction et ne constituent pas encore la base éditoriale vérifiée de Culture Foot.

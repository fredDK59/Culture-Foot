# Culture Foot — V11 → V13

## V11 — Le Premier Vrai Culture Foot
- Produit canonique issu du socle V5→V10.
- Catalogue d'entités canonique.
- Trois portes : recherche, exploration, surprise.
- Contrat produit explicite : INTENTION → RÉPONSE → CURIOSITÉS POSSIBLES → CHOIX.
- Base de navigation mobile-first et pages existantes réutilisées.

## V12 — Le Moteur De Curiosité
- Propositions facultatives.
- Aucune redirection forcée.
- Relations sémantiques entre joueur, club, compétition, saison, match, stade et transfert.
- Principe : PROPOSE_NOT_IMPOSE.

## V13 — Le Football À Grande Échelle
- Catalogue canonique extensible.
- Contrat de readiness.
- Préparation à l'industrialisation des données, médias, archives et couverture mondiale.
- Réutilisation des briques V6→V10 plutôt que duplication.

## Limite de validation
Le package est contrôlé statiquement. Le build Next/Prisma complet n'est pas déclaré validé tant que les dépendances npm et PostgreSQL ne sont pas disponibles dans l'environnement d'exécution.

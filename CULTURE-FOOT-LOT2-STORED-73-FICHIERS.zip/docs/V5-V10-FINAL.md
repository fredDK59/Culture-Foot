# Culture Foot V5 → V10 — Consolidation & Productisation

## Positionnement
V5→V10 est traité comme un seul programme produit. Les versions ne sont pas six applications empilées : elles sont six paliers d'une même architecture.

- **V5 — Produit solide** : consolidation V1→V4, contrat canonique, qualité, tests et UX cohérente.
- **V6 — Données vivantes** : ingestion, historisation, anomalies, provenance et automatisation.
- **V7 — Mémoire du football** : médias, archives, événements, documents et provenance média.
- **V8 — Machine temporelle avancée** : saisons, époques, snapshots, contexte et navigation temporelle.
- **V9 — Football Intelligence** : analyses reproductibles, indicateurs, comparaisons, scénarios et explications.
- **V10 — Culture Foot public** : readiness production, observabilité, sécurité, performance, internationalisation et gouvernance.

## Règle d'or
**Une seule source de vérité. Une seule grammaire UX. Plusieurs portes d'entrée.**

## Ce qui change par rapport à V4
V4 reste le moteur de découverte. V5 devient le socle canonique et V6→V10 s'appuient dessus. Les anciennes routes restent documentées pour compatibilité mais les nouvelles fonctionnalités doivent utiliser les contrats V5+.

## Critères de sortie V10
- schéma et routes canoniques documentés
- provenance et qualité attachables aux données
- ingestion idempotente et historisée
- médias séparés des données éditoriales
- navigation temporelle contextualisée
- analyses reproductibles et sourcées
- recherche/comparateur/découverte interconnectés
- parcours exportable et portable
- FR/EN préparés
- endpoints health/readiness
- scripts de validation statique
- checklist de déploiement et rollback

## Limite de vérification
Le projet livré est préparé et contrôlé statiquement. L'installation npm complète et la validation Prisma/Next de bout en bout nécessitent un environnement disposant des dépendances et d'une base PostgreSQL accessibles. Elles ne sont pas déclarées comme réussies ici.

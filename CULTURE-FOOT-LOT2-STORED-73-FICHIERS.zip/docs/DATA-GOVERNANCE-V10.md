# Gouvernance des données

## États de preuve
`VERIFIED`, `ESTIMATED`, `RECONSTRUCTED`, `PARTIAL`, `UNKNOWN`, `DISPUTED`.

## Pour chaque donnée significative
- définition
- périmètre
- période
- source
- date de récupération
- méthode
- statut de preuve
- comparabilité
- version précédente si elle existe

## Interdit
- inventer une valeur historique manquante
- mélanger des périmètres sans les nommer
- présenter une estimation comme un fait vérifié
- effacer silencieusement une correction historique

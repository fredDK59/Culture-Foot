# Culture Foot — Production Hardening

Cette passe ajoute les éléments vérifiables sans dépendre d'un fournisseur de données externe :

- environnement PostgreSQL local reproductible via Docker Compose ;
- exemple d'environnement local ;
- préflight structurel ;
- CI GitHub Actions pour install, validation, génération Prisma et build ;
- sitemap et robots ;
- error boundary et page 404 ;
- vérification de version, routes, modèles et client généré.

## Limite explicite

Le build de production n'est pas déclaré comme validé dans cet environnement tant que `npm ci`, PostgreSQL et les dépendances Prisma/Next n'ont pas pu être exécutés avec succès. Le workflow CI fournit le chemin de validation reproductible.

# Architecture Culture Foot V10

```text
SOURCES
  ↓
COLLECTE → RAW → NORMALISATION → IDENTIFICATION → CONTRÔLE
  ↓                                      ↓
VERSIONNEMENT ← PROVENANCE ← QUALITÉ ← RELATIONS
  ↓
KNOWLEDGE BASE
  ├─ entités
  ├─ saisons
  ├─ matchs
  ├─ transferts
  ├─ stades
  ├─ finances
  ├─ médias
  └─ snapshots temporels
  ↓
CALCULS / ANALYSES / INDEX
  ↓
API CANONIQUE
  ├─ recherche
  ├─ découverte
  ├─ comparateur
  ├─ machine temporelle
  ├─ analyses
  └─ parcours
  ↓
UX CULTURE FOOT
  ├─ Réponse
  ├─ Curiosités possibles
  ├─ Choix du visiteur
  └─ Voyage
```

## Contrats canoniques
Chaque ressource exposée au front doit pouvoir fournir :
- `id`
- `type`
- `label`
- `status`
- `updatedAt`
- `evidence`
- `sourceRefs`
- `links`

Les réponses de découverte doivent distinguer la réponse principale des propositions facultatives.

## Compatibilité
Les routes historiques `/api/v1`, `/api/v2`, `/api/v3`, `/api/v4` sont conservées pendant la transition. Les nouvelles routes `/api/v5` et suivantes ne doivent pas dépendre de leur format de réponse.

# Roadmap V11 → V13

V11 = rendre le produit concret.
V12 = rendre la découverte intelligente et volontaire.
V13 = rendre l'univers extensible et industrialisable.

La règle de non-régression est : ne pas casser les acquis V5→V10 et ne pas créer une nouvelle architecture parallèle.

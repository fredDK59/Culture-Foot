# Culture Foot — V14 → V20

Cette tranche consolide le maximum cohérent réalisable sans prétendre disposer de fournisseurs de données, de licences médias, de PostgreSQL actif ou d'un déploiement production.

## V14 — Données fédérées
- contrat fournisseur
- priorités de sources
- règles de déduplication et conflits
- replayabilité

## V15 — Réseau médias & archives
- objets média documentés
- statut des droits
- conservation de la source originale
- interdiction de déclarer un média publiable sans preuve de droits

## V16 — Observabilité
- signaux ingestion / DB / recherche / découverte / médias / API / UI
- sévérité
- corrélation et audit

## V17 — Bêta publique
- gates explicites : identité, provenance, mobile, recherche, découverte, vie privée, monitoring

## V18 — Football Intelligence
- analyses reproductibles
- méthodologie obligatoire
- sources obligatoires
- incertitude visible
- interdiction de fabriquer des données

## V19 — Couverture mondiale
- couverture mesurée par entité, géographie, période et métrique
- aucun périmètre présenté comme complet sans mesure

## V20 — Lancement
- contrat de release
- étapes internal / closed-beta / public-beta / public
- blockers explicites

## Limite honnête
Ce package reste une base logicielle et documentaire. La validation production réelle nécessite notamment l'installation des dépendances, la génération Prisma, une base PostgreSQL, les migrations, des fournisseurs de données réels, des sources médias/licences, des tests navigateur et un déploiement.

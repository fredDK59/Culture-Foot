# Release map V5 → V10

| Version | Livrable central | Test de réussite |
|---|---|---|
| V5 | Produit consolidé | une architecture canonique remplace l'empilement |
| V6 | Data pipeline | une source peut être ingérée, contrôlée et historisée |
| V7 | Media & archives | un média possède contexte, droits/provenance et liens |
| V8 | Time machine | une entité peut être replacée dans une époque/saison |
| V9 | Football intelligence | une analyse cite ses données et sa méthode |
| V10 | Public production | health/readiness + sécurité + rollback + observabilité |

## Principe de déploiement
V5→V10 doit pouvoir être livré progressivement derrière des feature flags. Une fonctionnalité nouvelle ne doit pas rendre indisponibles les fonctions historiques.

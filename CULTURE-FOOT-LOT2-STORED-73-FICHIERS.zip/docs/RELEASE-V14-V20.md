# Release V14 → V20

## Scope
This release is a consolidated extension of the Culture Foot V5→V13 base. It adds the contracts and routes required to move from a product prototype toward a governed, observable, globally measurable public platform.

## Delivered
- V14 Data Federation
- V15 Media & Archives Network
- V16 Observability
- V17 Public Beta Gates
- V18 Football Intelligence
- V19 Coverage Measurement
- V20 Launch Governance
- unified V20 product page
- static release validation

## Not claimed
No production build, Prisma generation, migration, PostgreSQL execution, browser E2E, external-provider ingestion, media-rights clearance or public deployment is claimed by this release.

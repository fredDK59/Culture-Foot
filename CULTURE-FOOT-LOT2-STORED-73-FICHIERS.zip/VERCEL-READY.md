# Culture Foot — Vercel Preview V3

This package is designed to let the visual product preview build and open before PostgreSQL is connected.

- `npm run build` runs `prisma generate` then `next build` only.
- No database push or seed runs during the Vercel build.
- Read-only pages gracefully show empty states when `DATABASE_URL` is not configured.
- Once Neon/PostgreSQL is connected, set `DATABASE_URL` in Vercel Preview and Production; normal Prisma reads/writes then resume.
- Database credentials must never be committed to GitHub or placed in the ZIP.

## Next step after the preview
1. Confirm the visual site opens on Vercel.
2. Connect PostgreSQL/Neon.
3. Add `DATABASE_URL` to Vercel Preview + Production.
4. Run the database schema/seed separately.

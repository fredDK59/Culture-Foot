import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const schemaPath = path.join(root, 'prisma/schema.prisma')
const schema = fs.readFileSync(schemaPath, 'utf8')
const models = new Map([...schema.matchAll(/^model\s+(\w+)\s*\{([\s\S]*?)^\}/gm)].map(m => [m[1], m[2]]))
const problems = []
for (const [source, body] of models) {
  for (const line of body.split('\n')) {
    if (!line.includes('@relation')) continue
    const match = line.match(/^\s*(\w+)\s+(\w+)(?:\?|\[\])?\s+@relation/)
    if (!match) continue
    const target = match[2]
    const targetBody = models.get(target)
    if (!targetBody) continue
    if (!new RegExp('\\b' + source + '\\b').test(targetBody)) {
      problems.push(`${source}.${match[1]} -> ${target}`)
    }
  }
}
if (problems.length) {
  console.error('Prisma relation problems:')
  for (const problem of problems) console.error(`- ${problem}`)
  process.exit(1)
}
console.log(JSON.stringify({ ok: true, models: models.size, relationProblems: 0 }, null, 2))

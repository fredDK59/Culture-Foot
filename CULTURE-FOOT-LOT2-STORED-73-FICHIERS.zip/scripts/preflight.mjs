import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const mustExist = [
  'package.json', 'prisma/schema.prisma', 'prisma/seed.ts',
  'app/page.tsx', 'app/layout.tsx', 'app/v20/page.tsx',
  'lib/db.ts', 'scripts/validate-culture-foot.mjs', 'docker-compose.yml'
]
const missing = mustExist.filter((f) => !fs.existsSync(path.join(root, f)))
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'))
const schema = fs.readFileSync(path.join(root, 'prisma/schema.prisma'), 'utf8')
const models = [...schema.matchAll(/^model\s+(\w+)\s*\{/gm)].map((m) => m[1])
const routes = []
function walk(dir) {
  if (!fs.existsSync(dir)) return
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name)
    if (fs.statSync(full).isDirectory()) walk(full)
    else if (name === 'route.ts') routes.push(path.relative(root, full))
  }
}
walk(path.join(root, 'app/api'))
const result = {
  ok: missing.length === 0 && new Set(models).size === models.length,
  version: pkg.version,
  node: process.version,
  prismaModels: models.length,
  apiRoutes: routes.length,
  missing,
  databaseConfigured: Boolean(process.env.DATABASE_URL),
  generatedClientPresent: fs.existsSync(path.join(root, 'generated/prisma/client.ts')),
}
console.log(JSON.stringify(result, null, 2))
process.exit(result.ok ? 0 : 1)

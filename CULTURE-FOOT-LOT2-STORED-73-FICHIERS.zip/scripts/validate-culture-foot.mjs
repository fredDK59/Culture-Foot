import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const required = [
  'docs/V5-V10-FINAL.md',
  'docs/ARCHITECTURE-V10.md',
  'docs/RELEASE-V5-V10.md',
  'docs/DATA-GOVERNANCE-V10.md',
  'lib/culture-foot/contracts.ts',
  'lib/culture-foot/discovery-policy.ts',
  'lib/culture-foot/data-quality.ts',
  'lib/culture-foot/time-machine.ts',
  'lib/culture-foot/readiness.ts',
  'app/api/v5/health/route.ts',
  'app/api/v5/discovery/route.ts',
  'app/api/v6/sources/route.ts',
  'app/api/v7/media/route.ts',
  'app/api/v8/time-machine/route.ts',
  'app/api/v9/analyses/route.ts',
  'app/api/v10/readiness/route.ts',
  'docs/V11-V13-FINAL.md',
  'docs/ROADMAP-V11-V13.md',
  'lib/v11/catalog.ts',
  'lib/v11/product.ts',
  'lib/v12/discovery.ts',
  'lib/v13/readiness.ts',
  'app/api/v11/product/route.ts',
  'app/api/v12/discovery/route.ts',
  'app/api/v13/catalog/route.ts',
  'app/api/v13/readiness/route.ts',
  'app/v13/page.tsx',
  'docs/V14-V20-MAXIMUM.md',
  'docs/RELEASE-V14-V20.md',
  'lib/v14/data-federation.ts',
  'lib/v15/media-network.ts',
  'lib/v16/observability.ts',
  'lib/v17/public-beta.ts',
  'lib/v18/intelligence.ts',
  'lib/v19/coverage.ts',
  'lib/v20/launch.ts',
  'app/api/v14/data-federation/route.ts',
  'app/api/v15/media-network/route.ts',
  'app/api/v16/observability/route.ts',
  'app/api/v17/public-beta/route.ts',
  'app/api/v18/intelligence/route.ts',
  'app/api/v19/coverage/route.ts',
  'app/api/v20/launch/route.ts',
  'app/v20/page.tsx',
]
const missing = required.filter((file) => !fs.existsSync(path.join(root, file)))
if (missing.length) {
  console.error('MISSING_FILES', missing)
  process.exit(1)
}
const version = fs.readFileSync(path.join(root, 'VERSION'), 'utf8').trim()
if (version !== '20.0.0') {
  console.error('BAD_VERSION', version)
  process.exit(1)
}
const schema = fs.readFileSync(path.join(root, 'prisma/schema.prisma'), 'utf8')
const models = [...schema.matchAll(/^model\s+(\w+)\s*\{/gm)].map((m) => m[1])
const unique = new Set(models)
if (models.length !== unique.size) {
  console.error('DUPLICATE_PRISMA_MODELS')
  process.exit(1)
}
// Lightweight Prisma relation consistency check: every explicit relation must have a
// corresponding field on the target model unless it is an implicit many-to-many.
const modelBodies = new Map([...schema.matchAll(/^model\s+(\w+)\s*\{([\s\S]*?)^\}/gm)].map((m) => [m[1], m[2]]))
const relationProblems = []
for (const [source, body] of modelBodies) {
  for (const line of body.split('\n')) {
    if (!line.includes('@relation')) continue
    const m = line.match(/^\s*(\w+)\s+(\w+)(?:\?|\[\])?\s+@relation/)
    if (!m) continue
    const target = m[2]
    if (!modelBodies.has(target)) continue
    const targetBody = modelBodies.get(target)
    if (!new RegExp('\\b' + source + '\\b').test(targetBody)) {
      relationProblems.push(`${source}.${m[1]} -> ${target}`)
    }
  }
}
if (relationProblems.length) {
  console.error('PRISMA_RELATION_PROBLEMS', relationProblems)
  process.exit(1)
}

const routeFiles = []
function walk(dir) {
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name)
    const stat = fs.statSync(full)
    if (stat.isDirectory()) walk(full)
    else if (name === 'route.ts') routeFiles.push(path.relative(root, full))
  }
}
walk(path.join(root, 'app/api'))
console.log(JSON.stringify({ ok: true, version, prismaModels: models.length, apiRoutes: routeFiles.length }, null, 2))
